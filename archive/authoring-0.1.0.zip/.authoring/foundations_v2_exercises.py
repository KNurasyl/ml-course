"""Author six independent exercise contracts; not part of learner launch flow."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]

def write(p,s):
    p=ROOT/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s.strip()+'\n',encoding='utf-8')

common='''from pathlib import Path
import importlib.util
import sys
import json
ROOT=Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
def load(path):
    spec=importlib.util.spec_from_file_location("learner_submission",path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module
def rejected(call):
    try:call()
    except (ValueError,TypeError):return
    raise AssertionError("invalid input was accepted")
'''
finish='''
if __name__=="__main__":
    if len(sys.argv)!=2:raise SystemExit("usage: check.py path/to/your_solution.py")
    try:
        checks=check(load(sys.argv[1]))
    except Exception as error:
        print(json.dumps({"passed":False,"error":type(error).__name__,"message":str(error)},ensure_ascii=True))
        raise SystemExit(1)
    print(json.dumps({"passed":True,"checks":checks,"understanding":"requires your explanation and a new case"},ensure_ascii=True))
'''
contracts={
'M00':('''def predict(x, w, b):
    """Return w*x+b; reject nonfinite or boolean/non-numeric inputs."""
    raise NotImplementedError("Implement predict")
''','''import math
def predict(x,w,b):
    if any(type(v) not in (int,float) or not math.isfinite(v) for v in (x,w,b)):
        raise ValueError('finite numbers required')
    return w*x+b
''','''def check(m):
    assert m.predict(-3,2,5)==-1
    assert m.predict(4,0,-2)==-2
    assert m.predict(.5,-4,3)==1
    for x in [True,float('nan'),float('inf'),'3']:
        rejected(lambda x=x:m.predict(x,2,1))
    rejected(lambda:m.predict(1,float('inf'),0))
    return ['negative_input','zero_weight','fraction','finite_contract']
'''),
'M01':('''def prepare(train, test):
    """Lists of finite numbers or None; fit mean on train only. Return
    {'mean':float,'train':list,'test':list}; reject empty/all-missing train."""
    raise NotImplementedError("Implement prepare")

def deduplicate(rows):
    """Rows have session_id/value. Equal copies collapse; conflicting copy raises."""
    raise NotImplementedError("Implement deduplicate")
''','''import math
def prepare(train,test):
    def valid(v):return v is None or (type(v) in (int,float) and math.isfinite(v))
    if not all(valid(v) for v in [*train,*test]):raise ValueError('bad numeric value')
    known=[v for v in train if v is not None]
    if not known:raise ValueError('no observed train values')
    mean=sum(known)/len(known)
    return {'mean':mean,'train':[mean if v is None else v for v in train],
            'test':[mean if v is None else v for v in test]}
def deduplicate(rows):
    unique={}
    for row in rows:
        sid=row['session_id']
        if sid in unique and unique[sid]!=row:raise ValueError('conflicting duplicate')
        unique[sid]=dict(row)
    return list(unique.values())
''','''def check(m):
    a=m.prepare([2,None,8],[None,1000])
    b=m.prepare([2,None,8],[None,-1000])
    assert a['mean']==b['mean']==5 and a['train']==[2,5,8] and a['test']==[5,1000]
    rejected(lambda:m.prepare([None,None],[5]))
    rejected(lambda:m.prepare([1,float('nan')],[]))
    rows=[{'session_id':'s1','value':2},{'session_id':'s1','value':2},{'session_id':'s2','value':9}]
    assert len(m.deduplicate(rows))==2
    rejected(lambda:m.deduplicate([{'session_id':'s','value':2},{'session_id':'s','value':3}]))
    return ['train_only_fit','missing_values','conflicting_duplicate','grain']
'''),
'M02':('''def search(ids, documents, query, k):
    """Return [(id, cosine), ...], decreasing score then id; reject invalid shapes,
    zero/nonfinite vectors, duplicate IDs, k outside 1..len(ids)."""
    raise NotImplementedError("Implement search")

def recall(found, relevant):
    """Set-based recall; raise ValueError when relevant is empty."""
    raise NotImplementedError("Implement recall")
''',None,'''import math
def check(m):
    ids=['V','U','W','X','Y'];D=[[2,0,0],[1,0,0],[0,1,0],[0,0,1],[-1,0,0]]
    rows=m.search(ids,D,[1,1,0],3)
    assert [r[0] for r in rows]==['U','V','W']
    assert all(abs(r[1]-2**-.5)<1e-12 for r in rows)
    assert m.recall(['U','U','V'],['U','W'])==.5
    assert [r[0] for r in m.search(ids,D,[10,10,0],2)]==['U','V']
    rejected(lambda:m.search(ids,D,[0,0,0],2))
    rejected(lambda:m.search(ids,D,[1,0],2))
    rejected(lambda:m.search(ids,D,[1,0,0],True))
    rejected(lambda:m.search(['a','a'],[[1,0],[0,1]],[1,0],1))
    rejected(lambda:m.recall(['U'],[]))
    return ['3D_cosine','ID_tie_rule','query_scale','set_recall','invalid_input']
'''),
'M03':('''def gradient(xs, ys, w, b):
    """Return (dMSE/dw,dMSE/db); equal nonempty finite lists and finite parameters."""
    raise NotImplementedError("Implement gradient")
''','''import math
def gradient(xs,ys,w,b):
    if not xs or len(xs)!=len(ys):raise ValueError('nonempty equal lengths required')
    if any(type(v) not in (float,int) or not math.isfinite(v) for v in [*xs,*ys,w,b]):
        raise ValueError('finite numeric values required')
    residual=[w*x+b-y for x,y in zip(xs,ys)]
    return 2*sum(e*x for e,x in zip(residual,xs))/len(xs),2*sum(residual)/len(xs)
''','''def check(m):
    for xs,ys,w,b in [([-2,0,3],[3,1,4],.7,-.2),([0,0],[1,3],2,0),([1],[4],0,0)]:
        def loss(w,b):return sum((w*x+b-y)**2 for x,y in zip(xs,ys))/len(xs)
        dw,db=m.gradient(xs,ys,w,b);h=1e-5
        assert abs(dw-(loss(w+h,b)-loss(w-h,b))/(2*h))<1e-7
        assert abs(db-(loss(w,b+h)-loss(w,b-h))/(2*h))<1e-7
    rejected(lambda:m.gradient([],[],0,0))
    rejected(lambda:m.gradient([1],[1,2],0,0))
    rejected(lambda:m.gradient([float('nan')],[1],0,0))
    return ['finite_difference_negative_zero_inputs','bias_gradient','mean_factor','contract']
'''),
'M04':('''def binomial_tail(n, minimum, p=.5):
    """P(X>=minimum); validate integer n>=0/minimum and probability p in [0,1]."""
    raise NotImplementedError("Implement binomial_tail")

def choose_size(rows, required_power=.8):
    """Rows contain n/exact_power; choose smallest qualifying n or None."""
    raise NotImplementedError("Implement choose_size")
''','''from math import comb,isfinite
def binomial_tail(n,minimum,p=.5):
    if type(n) is not int or type(minimum) is not int or n<0 or not isfinite(p) or not 0<=p<=1:
        raise ValueError('invalid binomial parameters')
    return sum(comb(n,k)*p**k*(1-p)**(n-k) for k in range(max(0,minimum),n+1))
def choose_size(rows,required_power=.8):
    if not 0<required_power<=1:raise ValueError('invalid power target')
    candidates=[r['n'] for r in rows if r['exact_power']>=required_power]
    return min(candidates) if candidates else None
''','''def check(m):
    assert m.binomial_tail(5,4)==6/32
    assert abs(m.binomial_tail(3,2,.6)-.648)<1e-12
    assert m.binomial_tail(0,0)==1
    assert m.binomial_tail(4,5)==0
    assert m.binomial_tail(4,4,1)==1
    rejected(lambda:m.binomial_tail(-1,0))
    rejected(lambda:m.binomial_tail(2,1,1.1))
    rows=[{'n':800,'exact_power':.89},{'n':200,'exact_power':.42},{'n':400,'exact_power':.65}]
    assert m.choose_size(rows)==800 and m.choose_size(rows,.95) is None
    return ['inclusive_tail','unequal_probability','boundary_cases','power_not_effect']
'''),
'M05':('''def split_records(df, train_before=144, validation_before=192):
    """Return train/validation/test/excluded row-ID lists. Keep groups whole;
    exclude a group spanning a boundary, preserve chronology."""
    raise NotImplementedError("Implement split_records")

def build_pipeline(C=1.):
    """Return sklearn pipeline with FitAudit first, train-only imputer/scaler,
    one-hot unknown-category handling, logistic classifier. Allowed FEATURES only.
    FitAudit and FEATURES may be imported from labs.M05.pipeline."""
    raise NotImplementedError("Implement build_pipeline")

def choose_threshold(y, probabilities, thresholds=(.25,.5,.75), fn_cost=2):
    """Minimize (fn_cost*FN+FP)/N using >=, tie -> smallest threshold."""
    raise NotImplementedError("Implement choose_threshold")
''',None,'''import numpy as np
import pandas as pd
from labs.M05.pipeline import make_data,check_fit_rows,FEATURES
def check(m):
    tiny=pd.DataFrame({'user_id':['a','a','b','b','c','c'],'day':[1,2,3,6,8,9]},index=list('ABCDEF'))
    s=m.split_records(tiny,5,8)
    assert {k:set(v) for k,v in s.items()}=={'train':{'A','B'},'validation':set(),'test':{'E','F'},'excluded':{'C','D'}}
    df=make_data(2026,difficult=True);parts=m.split_records(df)
    tr,va,te=[df.loc[parts[k]] for k in ['train','validation','test']]
    assert not set(tr.user_id)&set(va.user_id) and not set(tr.user_id)&set(te.user_id)
    assert max(tr.day)<min(va.day) and max(va.day)<min(te.day)
    assert set().union(*[set(v) for v in parts.values()])==set(df.index)
    model=m.build_pipeline(.1);model.fit(tr,tr.is_ready);check_fit_rows(model,tr.index)
    p=model.predict_proba(te)[:,1];assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
    changed=te.copy();changed.review_score_after=changed.is_ready*10000
    assert np.allclose(p,model.predict_proba(changed)[:,1]),'future column influences prediction'
    rejected(lambda:model.predict_proba(te.drop(columns=['track'])))
    assert m.choose_threshold([1,0,1,0],[.4,.3,.8,.6])==.25
    assert m.choose_threshold([0,1],[.4,.6],thresholds=(.3,.5,.7))==.5
    assert m.choose_threshold([1,0],[.3,.2],thresholds=(.25,.5),fn_cost=5)==.25
    return ['group_time_split','boundary_exclusion','train_fit_audit','unknown_and_missing','future_feature_ignored','threshold_cost']
''')}
for module,(starter,solution,checker) in contracts.items():
    write(f'exercises/{module}/starter.py',starter)
    write(f'exercises/{module}/check.py',common+checker+finish)
    if module=='M02':
        source=(ROOT/'labs/M02/demo.py').read_text(encoding='utf-8')
        solution=source[:source.index('def run():')]
    if module=='M05':
        solution='''import numpy as np
from labs.M05.pipeline import split_groups,FitAudit,FEATURES,NUMERIC
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler,OneHotEncoder
from sklearn.linear_model import LogisticRegression
def split_records(df,train_before=144,validation_before=192):
    return split_groups(df,train_before,validation_before)
def build_pipeline(C=1.):
    numeric=Pipeline([('impute',SimpleImputer(strategy='median')),('scale',StandardScaler())])
    prep=ColumnTransformer([('num',numeric,NUMERIC),('cat',OneHotEncoder(handle_unknown='ignore',sparse_output=False),['track'])],remainder='drop')
    return Pipeline([('audit',FitAudit()),('prepare',prep),('model',LogisticRegression(C=C,max_iter=1000))])
def choose_threshold(y,probabilities,thresholds=(.25,.5,.75),fn_cost=2):
    y=np.asarray(y);p=np.asarray(probabilities)
    if y.shape!=p.shape or y.ndim!=1 or not len(y):raise ValueError('equal nonempty vectors required')
    if not np.isin(y,[0,1]).all() or not np.isfinite(p).all() or ((p<0)|(p>1)).any():raise ValueError('invalid labels/probabilities')
    def cost(t):
        pred=p>=t
        return (fn_cost*int(((y==1)&~pred).sum())+int(((y==0)&pred).sum()))/len(y)
    return float(min(thresholds,key=lambda t:(cost(t),t)))
'''
    write(f'solutions/exercises/{module}/solution.py',solution)
    write(f'exercises/{module}/README.md',f'''# {module}: собственная реализация и проверка

Версия 1.1.0. Эти файлы — заготовка задания, а не готовое решение. Скопируй starter.py в submissions/{module}/solution.py. Реализуй контракты docstring; исходную заготовку сохраняй неизменной. Пустой starter намеренно не проходит проверку и не является сломанной лабораторной.

Из корня курса:

```powershell
.\\.venv\\Scripts\\python.exe exercises\\{module}\\check.py submissions\\{module}\\solution.py
```

Checker загружает **твой** Python-файл и проверяет его поведение на фиксированных случаях, включая ошибки. Не запускай чужой непроверенный файл. Exit code 0 означает прохождение перечисленных технических проверок; он не оценивает объяснение и самостоятельность. Сохрани JSON и собственное объяснение рядом с работой. При провале посмотри вход из check.py, воспроизведи его вручную и исправь причину.

После собственной попытки можно сравнить с [эталоном](../../solutions/exercises/{module}/solution.py). Проверка эталона той же командой с соответствующим путём подтверждает, что контракт выполним. После полного разбора реши вариант B, а через 3–7 дней вариант C из [модуля](../../course/modules/{module}.md). Ключи разных вариантов находятся в [решениях модуля](../../solutions/modules/{module}.md).

Окружение: существующий Python 3.11, requirements.lock.txt курса, CPU. Платных API и GPU нет. Все маленькие данные авторские. Для перехода дальше обязательны все предметные критерии, отсутствие критических ошибок и самостоятельное объяснение нового случая.
''')
print('6 exercise packages written')
