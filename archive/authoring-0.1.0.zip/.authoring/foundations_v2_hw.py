from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
head='''from pathlib import Path
import sys,json,importlib.util
ROOT=Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location("reference",Path(__file__).with_name("solution.py"))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
'''
tail='''
out=ROOT/"artifacts/foundation-hw"/Path(__file__).parent.name
out.mkdir(exist_ok=True,parents=True)
(out/"report.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
print(json.dumps(report,indent=2))
'''
bodies={
'M00':'''def experiment(xs,ys,candidates,new_x):
    rows=[]
    for w,b in candidates:
        predictions=[m.predict(x,w,b) for x in xs]
        mse=sum((p-y)**2 for p,y in zip(predictions,ys))/len(ys)
        rows.append({'w':w,'b':b,'predictions':predictions,'mse':mse})
    chosen=min(rows,key=lambda r:r['mse'])
    return {'candidates':rows,'model':{'w':chosen['w'],'b':chosen['b'],'version':'1.1.0-A','input_unit':'minutes'},'new_prediction':m.predict(new_x,chosen['w'],chosen['b'])}
report={'A':experiment([-2,0,3],[5,1,-5],[(-2,1),(-1,0)],4),
        'B':experiment([-4,0,2],[-4,-2,-1],[(.5,-2),(1,-1)],4),
        'C':{'physical_input_minutes':2,'same_input_seconds':120,'prediction_old':m.predict(2,-2,1),'prediction_new_preprocessed':m.predict(120/60,-2,1),'prediction_new_weight':m.predict(120,-2/60,1)}}
assert report['A']['new_prediction']==-7
assert report['A']['candidates'][1]['mse']==14/3
assert report['B']['candidates'][1]['mse']==2
assert len(set(report['C'][k] for k in ['prediction_old','prediction_new_preprocessed','prediction_new_weight']))==1
''',
'M01':'''import sqlite3
records=[{'session_id':'a','person':'A','value':2},{'session_id':'b','person':'A','value':None},{'session_id':'c','person':'B','value':8},{'session_id':'c','person':'B','value':8},{'session_id':'d','person':'C','value':None},{'session_id':'e','person':'C','value':1000}]
unique=m.deduplicate(records)
train=[r['value'] for r in unique if r['person'] in ['A','B']]
test=[r['value'] for r in unique if r['person']=='C']
with sqlite3.connect(':memory:') as connection:
    connection.execute('CREATE TABLE sessions(session_id TEXT PRIMARY KEY,person TEXT,value REAL)')
    connection.executemany('INSERT INTO sessions VALUES(?,?,?)',[(r['session_id'],r['person'],r['value']) for r in unique])
    counts=connection.execute('SELECT person,COUNT(*) FROM sessions GROUP BY person ORDER BY person').fetchall()
report={'A':m.prepare(train,test),'sql_counts':counts,'stage_rows':[len(records),len(unique)],'B':m.prepare([1,None,9],[None,100]),'C':{'session_mean':3,'person_mean':5}}
assert report['A']['mean']==5 and counts==[('A',2),('B',1),('C',2)]
assert m.prepare(train,[None,-1000])['mean']==5
try:m.deduplicate(unique+[{'session_id':'c','person':'B','value':9}])
except ValueError:report['conflict_rejected']=True
else:raise AssertionError('conflict must be rejected')
''',
'M02':'''ids=['V','U','W','X','Y'];D=[[2,0,0],[1,0,0],[0,1,0],[0,0,1],[-1,0,0]]
rows=[]
for q,gold in [([1,1,0],['U','W']),([0,0,1],['X','W'])]:
    ranked=m.search(ids,D,q,3);found=[r[0] for r in ranked]
    rows.append({'top3':ranked,'recall':{str(k):m.recall(found[:k],gold) for k in [1,2,3]}})
    assert m.search(ids[::-1],D[::-1],q,3)==ranked
ranked_b=m.search(ids+['Z'],D+[[0,2,0]],[1,1,0],3)
report={'A':rows,'mean_recall':[sum(row['recall'][str(k)] for row in rows)/2 for k in [1,2,3]],'B':{'top3':ranked_b,'recall_at_3':m.recall([r[0] for r in ranked_b],['U','W','Z'])},'C':{'recall':m.recall(['U','U','Y'],['U','W','X'])}}
assert report['mean_recall']==[.5,.5,.75]
assert report['B']['recall_at_3']==2/3
''',
'M03':'''import numpy as np
def train(xs,ys,penalty):
    w=b=0.;history=[]
    for step in range(400):
        dw,db=m.gradient(xs,ys,w,b);dw+=2*penalty*w
        w,b=w-.08*dw,b-.08*db
        mse=sum((w*x+b-y)**2 for x,y in zip(xs,ys))/len(xs)
        history.append({'step':step+1,'w':w,'b':b,'mse':mse,'penalty':penalty*w*w,'objective':mse+penalty*w*w})
    return {'w':w,'b':b,'final':history[-1],'history':history}
x=[-1,0,2];y=[4,1,-5]
report={'A_no_penalty':train(x,y,0),'A_penalty':train(x,y,.5),'B':train(x,[2*v-1 for v in x],1)}
assert np.allclose([report['A_no_penalty']['w'],report['A_no_penalty']['b']],[-3,1],atol=1e-8)
assert np.allclose([report['A_penalty']['w'],report['A_penalty']['b']],[-84/37,28/37],atol=1e-8)
assert np.allclose([report['B']['w'],report['B']['b']],[28/23,-17/23],atol=1e-8)
assert np.allclose(m.gradient(x,y,.7,-.2),m.gradient(x+x,y+y,.7,-.2))
report['C_duplicate_gradient_unchanged']=True
''',
'M04':'''import numpy as np
from scipy.stats import binomtest
from labs.M04.bridges import paired_plan
def compare(a,b,seed):
    d=np.asarray(b)-np.asarray(a);rng=np.random.default_rng(seed)
    means=d[rng.integers(0,len(d),size=(20000,len(d)))].mean(1)
    wins=int((d>0).sum());losses=int((d<0).sum())
    return {'a_mean':float(np.mean(a)),'b_mean':float(np.mean(b)),'differences':d.tolist(),'effect':float(d.mean()),'wins':wins,'losses':losses,'sign_two_sided_p':float(binomtest(wins,wins+losses).pvalue) if wins+losses else 1.,'bootstrap_95':np.quantile(means,[.025,.975]).tolist(),'seed':seed,'resamples_are_not_new_people':True}
report={'A':compare([1,0,1,0,1,0,0,1,0,1],[1,1,1,0,0,1,1,1,0,1],101),
        'B':compare([0,0,1,1,0,1],[1,0,0,1,1,1],102),
        'C':{'effect':2/12,'sign_two_sided_p':float(binomtest(4,6).pvalue)},
        'planning':paired_plan(improve=.15,regress=.05,seed=73)}
assert report['A']['effect']==.2 and report['A']['sign_two_sided_p']==.625
assert report['B']['effect']==1/6 and report['B']['sign_two_sided_p']==1
assert report['C']['sign_two_sided_p']==.6875
'''}
for module,body in bodies.items():
 p=ROOT/f'solutions/exercises/{module}/run_hw.py';p.write_text(head+body+tail,encoding='utf-8')
print('5 full HW reference experiments written')
