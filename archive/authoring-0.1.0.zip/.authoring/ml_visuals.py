from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'course/assets'
PREVIEW=ROOT/'artifacts/visual-check-ml';PREVIEW.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})

def save(fig,name):
    fig.savefig(ASSETS/f'{name}.svg',bbox_inches='tight',facecolor='#f5f7fc')
    fig.savefig(PREVIEW/f'{name}.png',dpi=120,bbox_inches='tight',facecolor='#f5f7fc')
    plt.close(fig)

fig,ax=plt.subplots(figsize=(10,4))
for i,arrived in enumerate([0,1,2,3]):
    start=2*i;ax.barh(i,start-arrived,left=arrived,color='#b9c9dd',label='Ожидание' if i==0 else None)
    ax.barh(i,2,left=start,color='#2879ad',label='Вычисление модели' if i==0 else None)
    ax.text(start+1,i,str(2+i)+' с всего',ha='center',va='center',color='white')
ax.set_yticks(range(4),['Запрос 1','Запрос 2','Запрос 3','Запрос 4']);ax.invert_yaxis()
ax.set_xlabel('Секунды от начала наблюдения');ax.set_title('Очередь увеличивает полную задержку при одинаковых 2 с вычисления')
ax.legend(loc='lower right');fig.tight_layout();save(fig,'M06-L03')

fig,ax=plt.subplots(figsize=(9,4))
ax.plot([1,2,3,4],[.7,.4,.2,.1],'o-',label='train');ax.plot([1,2,3,4],[.72,.45,.42,.55],'o-',label='validation')
ax.axvline(3,color='#4b826d',linestyle='--');ax.annotate('Сохранить эпоху 3\nпо validation',xy=(3,.42),xytext=(2.6,.68),arrowprops={'arrowstyle':'->'})
ax.set(xlabel='Эпоха',ylabel='Loss',title='Меньший train loss не гарантирует лучшего обобщения',xticks=[1,2,3,4]);ax.legend();fig.tight_layout();save(fig,'M07-L04')

q=np.array([1.,0.,-1.]);scores=q[:,None]*q[None,:];a=np.exp(scores-scores.max(1,keepdims=True));a/=a.sum(1,keepdims=True)
fig,axes=plt.subplots(1,2,figsize=(10,4),gridspec_kw={'width_ratios':[1.4,1]})
ax=axes[0];im=ax.imshow(a,cmap='Blues',vmin=0,vmax=1)
for i in range(3):
 for j in range(3):ax.text(j,i,f'{a[i,j]:.3f}',ha='center',va='center',color='white' if a[i,j]>.5 else '#17314d')
ax.set(xticks=range(3),yticks=range(3),xticklabels=['K1','K2','K3'],yticklabels=['Q1','Q2','Q3'],title='Softmax по ключам → сумма строки 1')
axes[1].barh(range(3),a@np.array([10,20,30]),color='#2879ad')
axes[1].set(yticks=range(3),yticklabels=['O1','O2','O3'],xlabel='Взвешенная сумма V',xlim=(0,32))
for i,v in enumerate(a@np.array([10,20,30])):axes[1].text(v+.5,i,f'{v:.3f}',va='center')
fig.suptitle('Attention: Q=K=[1,0,−1], V=[10,20,30], dₖ=1');fig.tight_layout();save(fig,'M08-L03')

fig,ax=plt.subplots(figsize=(7,5));mask=np.tril(np.ones((4,4)));weights=mask/mask.sum(1,keepdims=True)
ax.imshow(weights,cmap='Blues',vmin=0,vmax=1)
for i in range(4):
 for j in range(4):ax.text(j,i,f'{weights[i,j]:.2f}' if j<=i else 'запрет',ha='center',va='center',fontsize=12,color='white' if weights[i,j]>.6 else '#17314d')
ax.set(xticks=range(4),yticks=range(4),xticklabels=['токен 1','токен 2','токен 3','токен 4'],yticklabels=['позиция 1','позиция 2','позиция 3','позиция 4'],title='Causal mask: будущие позиции имеют вес 0')
fig.tight_layout();save(fig,'M08-L04')

fig,ax=plt.subplots(figsize=(10,4));parts=[60,180,200,40,20,64];labels=['Инструкция','История','Источники','Вопрос','Маркеры','Резерв'];colors=['#16466e','#337eaa','#5f9eaa','#74b6a7','#acc5cb','#d38757']
for row,values in enumerate([parts,[60,100,200,40,20,64]]):
 left=0
 for size,label,color in zip(values,labels,colors):
  ax.barh(row,size,left=left,color=color,label=label if row==0 else None)
  if size>=40:ax.text(left+size/2,row,str(size),ha='center',va='center',color='white')
  left+=size
 ax.text(left+5,row,str(left),va='center')
ax.axvline(512,color='#bd3d3d',ls='--',label='Лимит 512');ax.set(yticks=[0,1],yticklabels=['До сокращения','После удаления пары'],xlabel='Токены (учебные числа)',xlim=(0,620),title='Нужно оставить место для ответа, а не только входа')
ax.invert_yaxis();ax.legend(loc='upper center',bbox_to_anchor=(.5,-.2),ncol=3,fontsize=10);fig.tight_layout();save(fig,'M09-L02')

fig,ax=plt.subplots(figsize=(9,4));vals=[800,400,200];bars=ax.bar(['float32','float16','int8\nбез накладных данных'],vals,color=['#2879ad','#438c95','#71a494'])
for b,v in zip(bars,vals):ax.text(b.get_x()+b.get_width()/2,v+12,f'{v} MB',ha='center')
ax.set(ylim=(0,930),ylabel='Миллионы байт',title='Оценка только весов для 200 млн параметров')
ax.text(.5,.89,'Кэш, активации и runtime прибавляются отдельно',transform=ax.transAxes,ha='center');fig.tight_layout();save(fig,'M09-L04')

fig,ax=plt.subplots(figsize=(9,4));names=['B','A','D','C'];values=[1/12+1/11,1/11+1/13,1/12,1/13]
ax.barh(names,values,color=['#2879ad','#2879ad','#97aec4','#97aec4']);ax.invert_yaxis()
for i,v in enumerate(values):ax.text(v+.003,i,f'{v:.5f}',va='center')
ax.set(xlim=(0,.22),xlabel='RRF score, c=10',title='Слияние [A,B,C] и [B,D,A]: B получает два высоких ранга')
fig.tight_layout();save(fig,'M10-L03')

fig,ax=plt.subplots(figsize=(7,4));cm=np.array([[1,1],[1,1]]);ax.imshow(cm,cmap='Blues',vmin=0,vmax=2)
labels=[['TN=1','FP=1'],['FN=1','TP=1']]
for i in range(2):
 for j in range(2):ax.text(j,i,labels[i][j],ha='center',va='center',fontsize=20)
ax.set(xticks=[0,1],yticks=[0,1],xticklabels=['Judge: неверно','Judge: верно'],yticklabels=['Ручная: неверно','Ручная: верно'],title='Учебная confusion matrix: 2 совпадения из 4')
fig.tight_layout();save(fig,'M11-L04')
print('8 quantitative SVG figures and PNG previews generated')
