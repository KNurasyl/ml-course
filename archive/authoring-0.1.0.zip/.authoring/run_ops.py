from pathlib import Path
import runpy
folder = Path(__file__).resolve().parent
scope = runpy.run_path(str(folder / 'build_ops_voice.py'))
exec((folder / 'ops_finalize.py').read_text(encoding='utf-8'), scope)
