"""Authoring helper; Pages remain the canonical source of lesson prose."""
from pathlib import Path
import json
import sys
import textwrap

import nbformat as nbf

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from mlcourse.pilot import make_dataset, run_experiment
import pandas as pd


def md(text):
    return nbf.v4.new_markdown_cell(textwrap.dedent(text).strip())


def code(text):
    return nbf.v4.new_code_cell(textwrap.dedent(text).strip())


SETUP = '''
from pathlib import Path
import sys
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path.cwd().resolve()
while not (ROOT / "src" / "mlcourse" / "pilot.py").is_file():
    if ROOT == ROOT.parent:
        raise RuntimeError("Откройте Jupyter из корня ml-llm-course")
    ROOT = ROOT.parent
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))
from mlcourse.pilot import (
    mse, predict_line, linear_gradient, central_difference, fit_standardizer,
    matvec, fit_gradient, make_dataset, run_experiment, predict_payload,
)
plt.rcParams.update({"figure.figsize": (7.2, 4.2), "font.size": 11,
                     "axes.spines.top": False, "axes.spines.right": False})
FIGURES = ROOT / "artifacts" / "figures"
FIGURES.mkdir(parents=True, exist_ok=True)
print("Данные: искусственные учебные примеры. CPU. Состояние ученика не оценивается автоматически.")
'''

LESSONS = [
{
"id":"P01", "title":"Входы и параметры модели", "goal":"Различить вход x, параметры w/b и результат вычисления; вычислить новый прогноз без изменения параметров.",
"before":"Подстановка числа в функцию. Полный урок и диагностика находятся в Pages; адрес указан в course-manifest.json.",
"explanation":"Рассмотрим искусственные пары (1,3), (2,5), (3,7). Формула y = wx + b задаёт семейство моделей. При w=2 и b=1 она совпадает с этими тремя ответами. Это удобный учебный случай, а не доказательство надёжности на реальных данных.",
"examples":[('Вычислить прогнозы', '''
x = np.array([1., 2., 3.]); y = np.array([3., 5., 7.])
w, b = 2., 1.
prediction = w * x + b
display(pd.DataFrame({"x": x, "известный y": y, "предсказание": prediction}))
assert np.array_equal(prediction, y)
print("Новый вход x=4:", w * 4 + b)
'''),('Связать формулу с графиком', '''
fig, ax = plt.subplots()
grid = np.linspace(0, 4, 50)
ax.scatter(x, y, color="#1f5a99", label="Учебные примеры")
ax.plot(grid, w * grid + b, color="#333333", label="y = 2x + 1")
ax.set(xlabel="Вход x, условные единицы", ylabel="Ответ y, условные единицы", title="Простая линейная модель")
ax.legend(); fig.tight_layout()
fig.savefig(FIGURES / "P01_model.png", dpi=130)
plt.show()
''')],
"guided":"Измените только x на 5. Затем верните x и измените b на 0. Запишите, чем отличаются эти действия.",
"task":"На парах (1,5), (2,8), (3,11) сравните параметры (w=2,b=2) и (w=3,b=2). Вычислите прогноз при x=4. Объясните, почему совпадения трёх точек недостаточно для обещания будущего качества.",
"solution":'''new_x = np.array([1., 2., 3.]); new_y = np.array([5., 8., 11.])
for w_try, b_try in [(2, 2), (3, 2)]:
    print((w_try, b_try), predict_line(new_x, w_try, b_try).tolist())
assert np.array_equal(predict_line(new_x, 3, 2), new_y)
assert predict_line([4], 3, 2)[0] == 14
print("Параметры (3,2); новый прогноз 14. Нужна отдельная проверка на новых примерах.")''',
"rubric":"Вход и параметры названы верно; новый прогноз 14; обучение не приписано каждому вызову; ограниченность данных объяснена.",
"starter_rubric":"Вход и параметры названы верно; новый прогноз вычислен с выбранными параметрами и проверен подстановкой; обучение не приписано каждому вызову; ограниченность данных объяснена.",
"retry":"Новый пример: y=4x−1. Найдите ответы для x=0,2 и объясните, что фиксировано при инференсе.",
"source":"https://developers.google.com/machine-learning/crash-course/linear-regression",
},
{
"id":"P02", "title":"Ошибка и выбор параметров", "goal":"Посчитать MSE, сравнить настройки и отделить алгоритм подбора от выбранной модели.",
"before":"P01: модель и параметры; среднее арифметическое и квадрат числа.",
"explanation":"MSE — среднее квадратов разностей предсказания и известного ответа. Ошибки разных знаков не сокращаются. Выбирая параметры по ошибке на примерах, мы выполняем простейшее обучение; при этом выбранная метрика выражает лишь часть требований задачи.",
"examples":[('Разобрать вычисление ошибки', '''
x = np.array([1., 2., 3.]); y = np.array([3., 5., 7.])
pred_a, pred_b = predict_line(x, 2, 1), predict_line(x, 1, 1)
display(pd.DataFrame({"y": y, "B": pred_b, "остаток B-y": pred_b-y, "квадрат": (pred_b-y)**2}))
print("MSE A:", mse(y, pred_a), "MSE B:", mse(y, pred_b))
assert np.isclose(mse(y, pred_b), 14/3)
'''),('Подобрать параметры среди кандидатов', '''
candidates = [(1, 1), (2, 0), (2, 1)]
scores = [(w, b, mse(y, predict_line(x, w, b))) for w, b in candidates]
display(pd.DataFrame(scores, columns=["w", "b", "MSE train"]))
chosen = min(scores, key=lambda row: row[2])
assert chosen[:2] == (2, 1)
''')],
"guided":"Для параметров (2,0) посчитайте каждую ошибку вручную. Должно получиться три одинаковых квадрата; объясните причину.",
"task":"Реализуйте собственную функцию mse(actual, predicted), включая проверки пустых списков, одинаковой длины и конечности чисел. Проверьте её на новых y=[5,8,11] с предсказаниями двух кандидатов из P01. Для CLI сохраните функцию в отдельный .py файл и выполните tools/check_submission.py <файл> --task mse.",
"solution":'''def mse_answer(actual, predicted):
    if len(actual) == 0 or len(actual) != len(predicted):
        raise ValueError("Нужны непустые списки одинаковой длины")
    if not all(np.isfinite(v) for v in [*actual, *predicted]):
        raise ValueError("Нужны конечные числа")
    return sum((a-p)**2 for a, p in zip(actual, predicted)) / len(actual)
assert np.isclose(mse_answer([5, 8, 11], [4, 6, 8]), 14/3)
assert mse_answer([5, 8, 11], [5, 8, 11]) == 0
print("Новый набор: MSE неверного кандидата 14/3, верного 0.")''',
"rubric":"Формула использует квадрат, а не знак или модуль; знаменатель — число примеров; некорректные входы отклоняются; минимум ошибки интерпретируется в рамках данных.",
"retry":"Посчитайте MSE для actual=[0,2], predicted=[1,1]. Затем объясните отличие MSE=1 от средней ошибки=0.",
"source":"https://developers.google.com/machine-learning/crash-course/linear-regression/loss",
},
{
"id":"P03", "title":"Разделение обучения и проверки", "goal":"Отделить fit от transform и не использовать тестовые данные при подготовке модели.",
"before":"P02: выбор по ошибке, среднее; новое понятие scale вводится в этом примере.",
"explanation":"У нормализации тоже есть выученные параметры: среднее и масштаб. Их определяют на train и применяют к новым данным неизменно. Попадание test в fit нарушает независимость проверки, даже если в конкретном маленьком примере метрика случайно не улучшилась.",
"examples":[('Подготовить независимые части', '''
train_x = np.array([0., 1., 2.]); train_y = np.array([1., 3., 5.])
test_x = np.array([3., 4.]); test_y = np.array([7., 9.])
scaler = fit_standardizer(train_x)
print("mean train:", scaler.mean, "std train:", scaler.scale)
display(pd.DataFrame({"test x": test_x, "transform через train": scaler.transform(test_x)}))
assert scaler.mean == 1
assert np.isclose(scaler.scale, np.sqrt(2/3))
'''),('Показать неправильный fit', '''
leaky_scaler = fit_standardizer(np.concatenate([train_x, test_x]))
print("Неправильное среднее:", leaky_scaler.mean)
assert leaky_scaler.mean == 2
print("Правильная модель y=2x+1: test MSE =", mse(test_y, predict_line(test_x, 2, 1)))
print("Здесь test используется только для вычисления итоговой ошибки, а не выбора параметров.")
''')],
"guided":"Отметьте, какие строки обучают преобразование, какие только применяют его. Почему transform теста не должен менять scaler.mean?",
"task":"Новая задача: train x=[1,2,3], test x=[4,5], зависимость y=2x+1. Найдите среднее только train и ошибочное среднее всех пяти входов. Исправьте fit(concatenate(train,test)) → transform(train) → transform(test). Для центрирования z=x−mean_train выразите y через z. Затем объясните, почему реплики одного собеседования должны попадать в одну часть данных.",
"solution":'''new_train_x = np.array([1., 2., 3.]); new_test_x = np.array([4., 5.])
fixed_scaler = fit_standardizer(new_train_x)
transformed_train = fixed_scaler.transform(new_train_x)
transformed_test = fixed_scaler.transform(new_test_x)
assert fixed_scaler.mean == 2
assert fit_standardizer(np.concatenate([new_train_x, new_test_x])).mean == 3
assert np.isclose(transformed_train.mean(), 0)
np.testing.assert_allclose(transformed_test, np.array([2., 3.]) / np.sqrt(2/3))
z = new_test_x - fixed_scaler.mean
np.testing.assert_allclose(2*z + 5, 2*new_test_x + 1)
print("Среднее train=2; всех данных=3. При z=x−2 получаем y=2z+5. Центрирование и стандартизация — разные преобразования.")
print("Реплики одной сессии распределяем совместно, а не как независимые строки.")''',
"rubric":"fit получает только train; тест не влияет на параметры или выбор решения; группировка по сессиям объяснена. Критическая ошибка — повторно настроить модель по финальному тесту.",
"retry":"Временной ряд: можно ли перемешать будущие и прошлые записи? Опишите разделение для прогноза следующей недели.",
"source":"https://scikit-learn.org/stable/common_pitfalls.html",
},
{
"id":"P04", "title":"Векторы и размерности", "goal":"Связать скалярное произведение с линейным предсказанием и проверить формы массивов.",
"before":"Сложение и умножение; массивы Python. Здесь вводится умножение матрицы на вектор.",
"explanation":"Строка матрицы содержит признаки одного примера. Вектор весов содержит по одному коэффициенту на признак. Матрица (n,d), умноженная на вектор (d,), даёт n прогнозов. Число примеров и число признаков выполняют разные роли.",
"examples":[('Вычислить скалярное произведение', '''
a = np.array([1., 2.]); b = np.array([3., 4.])
print("Вручную:", 1*3 + 2*4, "NumPy:", a @ b)
assert a @ b == 11
'''),('Проверить матрицу и веса', '''
X = np.array([[1., 2., 3.], [4., 5., 6.]])
w = np.array([1., 0., -1.])
print("X:", X.shape, "w:", w.shape, "ответ:", (X @ w).shape)
np.testing.assert_array_equal(matvec(X, w), [-2, -2])
display(pd.DataFrame(X, columns=["признак 1", "признак 2", "признак 3"]))
try:
    matvec(X, [1, 2])
except ValueError as error:
    print("Ожидаемая ошибка:", error)
''')],
"guided":"Объясните два числа в X.shape. Найдите вручную прогноз первой строки. Почему вторая строка дала такое же число?",
"task":"Для X=[[2,0],[1,3]], w=[1,2], b=-1 рассчитайте ответ вручную и через NumPy. Затем придумайте несовместимые размеры и объясните ошибку до запуска.",
"solution":'''new_X = np.array([[2., 0.], [1., 3.]])
new_w = np.array([1., 2.]); new_b = -1
answer = new_X @ new_w + new_b
np.testing.assert_array_equal(answer, [1, 6])
print("Результат:", answer, "форма:", answer.shape)
print("Матрица (2,2) несовместима с вектором (3,), поскольку число признаков не совпадает.")''',
"rubric":"Ответ [1,6]; формы объяснены; broadcasting не используется для сокрытия несовместимых входов.",
"starter_rubric":"Ответ вычислен вручную и через NumPy; оба результата совпадают; формы объяснены; broadcasting не используется для сокрытия несовместимых входов.",
"retry":"Что изменится в размерах, если добавить третью строку? А третий признак?",
"source":"https://numpy.org/doc/stable/user/absolute_beginners.html",
},
{
"id":"P05", "title":"Модель как сервис", "goal":"Выделить границу API, версию модели и обработку некорректного запроса.",
"before":"P01–P03; знакомые HTTP и JSON. Новая тема — отдельный жизненный цикл параметров модели.",
"explanation":"Обучение может выполняться отдельно от сервиса. Сервис получает параметры конкретной версии и применяет их. Сохранение истории запросов — изменение состояния приложения, но не обязательно обучение. Граница API проверяет вход до численного вычисления.",
"examples":[('Проверить контракт предсказания', '''
request = {"x": 4}
response = predict_payload(request)
print(response)
assert response == {"prediction": 9., "model_version": "v1"}
'''),('Проверить невалидные входы', '''
for bad in [{}, {"x": "4"}, {"x": float("nan")}, {"x": True}]:
    try:
        predict_payload(bad)
    except ValueError as error:
        print(type(bad).__name__, "→ отклонён:", error)
    else:
        raise AssertionError("Некорректный запрос принят")
''')],
"guided":"Нарисуйте запрос → валидация → параметры v1 → предсказание → ответ. Добавьте место хранения версии и метрики ошибок.",
"task":"Составьте контракт POST /predict и минимум три негативных сценария. Затем опишите выпуск v2 и возврат на v1. Для проверки функции можно использовать tools/check_submission.py <файл> --task predict. Исполняемый HTTP-обработчик есть в mlcourse.pilot.prediction_handler; интеграционный тест запускает его только на 127.0.0.1.",
"solution":'''contract = {
    "method": "POST", "path": "/predict", "input": {"x": 4},
    "success": {"prediction": 9., "model_version": "v1"},
    "invalid": "HTTP 400: отсутствует x, строка вместо числа, NaN/Infinity",
    "release": "Проверить v2 на отдельном наборе; сохранить v1; переключить версию; наблюдать ошибки.",
    "rollback": "Вернуть прежние параметры и запись версии; не переобучать во время отката."
}
print(json.dumps(contract, ensure_ascii=False, indent=2))''',
"rubric":"Контракт совпадает с кодом; версия возвращается; обучение отделено от обработки запроса; описаны проверка и откат.",
"retry":"Что произойдёт, если код нормализации обновили, а параметры модели оставили прежними?",
"source":"https://docs.python.org/3/library/http.server.html",
},
{
"id":"P06", "title":"Проверка сохранения понятий", "goal":"Самостоятельно объяснить, что изменяется в модели, контексте и приложении.",
"before":"P01–P05. Сначала ответить без конспекта; незнакомые слова контекст и индекс изучить по уроку Pages.",
"explanation":"Эта работа различает восстановление знаний и копирование старой таблицы. Численный пример можно проверить программой, а причины и архитектурные связи необходимо объяснить наставнику.",
"examples":[('Проверить фиксированную модель на другом входе', '''
frozen_parameters = {"w": 2., "b": 1.}
before = frozen_parameters.copy()
answer = predict_line([-2, 0, 5], **frozen_parameters)
assert frozen_parameters == before
print("Новые ответы:", answer.tolist(), "параметры не изменены:", frozen_parameters == before)
''')],
"guided":"Вспомните без записи разницу между обучением и применением. После своей попытки сверьтесь с P01–P03.",
"task":"Разберите пять действий: новый вход, сохранение истории в БД, пересчёт весов по новым примерам, добавление документа в поисковый индекс, передача найденного текста в запрос LLM. Для каждого укажите, что именно меняется и какие сведения ещё нужны. Не приписывайте скрытое дообучение любому чату.",
"solution":'''classification = pd.DataFrame([
    ["новый вход", "вход вычисления", "нет"],
    ["история в БД", "состояние приложения", "само по себе нет"],
    ["пересчёт весов", "параметры модели", "да"],
    ["документ в индексе", "данные поиска", "само по себе нет"],
    ["текст в запросе LLM", "контекст запроса", "само по себе нет"],
], columns=["действие", "что изменилось", "изменение весов"])
display(classification)
print("Если система дополнительно запускает обучение, это отдельный процесс, который нужно явно подтвердить.")''',
"rubric":"Причины объяснены своими словами; история и индекс не названы весами; неизвестное поведение не выдумывается. Автоматический запуск этой таблицы не подтверждает усвоение.",
"retry":"Изменили только системную инструкцию интервьюера. Что изменилось? Затем объясните случай, когда отдельно обучили адаптер.",
"source":"https://developers.google.com/machine-learning/glossary",
},
{
"id":"P07", "title":"Производная и проверка градиента", "goal":"Объяснить скорость изменения и сопоставить аналитическую производную с численной.",
"before":"Функции, разность, деление; P02 об ошибке. Частная производная рассматривает один параметр при фиксированных остальных.",
"explanation":"Для f(x)=x² производная равна 2x. В точке x=2 она равна 4: для достаточно малого изменения входа изменение функции приблизительно в четыре раза больше. Центральная разность использует две близкие точки и приближает наклон; слишком маленький шаг может усилить ошибки округления.",
"examples":[('Сравнить формулу и конечную разность', '''
f = lambda value: value**2
numeric = central_difference(f, 2., epsilon=1e-5)
print("Аналитически:", 4, "численно:", numeric)
assert np.isclose(numeric, 4, atol=1e-8)
'''),('Показать касательную', '''
grid = np.linspace(0.5, 3.5, 120)
fig, ax = plt.subplots()
ax.plot(grid, grid**2, color="#1f5a99", label="f(x)=x²")
ax.plot(grid, 4 + 4*(grid-2), color="#333333", linestyle="--", label="Касательная при x=2")
ax.scatter([2], [4], color="#b56c19")
ax.set(xlabel="x", ylabel="f(x)", title="Производная как наклон")
ax.legend(); fig.tight_layout(); fig.savefig(FIGURES / "P07_derivative.png", dpi=130); plt.show()
'''),('Проверить частные производные ошибки', '''
x = np.array([0., 1., 2.]); y = np.array([1., 3., 5.])
dw, db = linear_gradient(x, y, 0, 0)
numeric_dw = central_difference(lambda w: mse(y, predict_line(x, w, 0)), 0)
numeric_db = central_difference(lambda b: mse(y, predict_line(x, 0, b)), 0)
np.testing.assert_allclose([dw, db], [numeric_dw, numeric_db], atol=1e-7)
print("dL/dw:", dw, "dL/db:", db)
''')],
"guided":"Объясните, что фиксировано при вычислении производной по w. Проверьте f'(3) для f(x)=x².",
"task":"Для g(t)=(t+1)² выведите производную и проверьте её в t=2 центральной разностью. Объясните знак. Для одного примера x=2, y=5 при w=1, b=0 рассчитайте ошибку e=wx+b−y и производные квадрата ошибки по w и b.",
"solution":'''g = lambda t: (t+1)**2
assert np.isclose(central_difference(g, 2), 6, atol=1e-8)
assert 2*(2+1) == 6
error = 1*2 + 0 - 5
assert error == -3
np.testing.assert_allclose(linear_gradient([2], [5], 1, 0), [-12, -6])
print("g'(2)=6: малое увеличение t увеличивает g. e=-3, dL/dw=-12, dL/db=-6.")''',
"rubric":"Производная не перепутана со значением функции; знак объяснён; численная проверка не используется как точное равенство для всех epsilon.",
"retry":"Для h(t)=(t−3)² вычислите h'(4) и объясните, в какую сторону уменьшать h. Затем сравните несколько epsilon.",
"source":"https://developers.google.com/machine-learning/crash-course/linear-regression/gradient-descent",
},
{
"id":"P08", "title":"Цикл обучения и шаг", "goal":"Выполнить обновление параметров и распознать расходимость.",
"before":"P07: производная и частные производные; P02: MSE.",
"explanation":"Обновление w_next = w − learning_rate × gradient делает небольшой шаг против роста ошибки. Для g(w)=(w−3)² из w=0 шаг 0.1 даёт 0.6, затем 1.08. Большой шаг может перескочить минимум и увеличить ошибку. Для нескольких параметров обновляем каждый его производной.",
"examples":[('Один параметр и три шага обучения', '''
fig, ax = plt.subplots()
for rate, style, color in [(0.1, "-", "#1f5a99"), (0.5, "--", "#333333"), (1.1, ":", "#b56c19")]:
    w_scalar = 0.; losses = []
    for step in range(18):
        losses.append((w_scalar-3)**2)
        w_scalar -= rate * 2*(w_scalar-3)
    ax.plot(np.arange(len(losses)), np.maximum(losses, 1e-14), linestyle=style, color=color, label=f"Шаг {rate}")
ax.set_yscale("log")
ax.set(xlabel="Номер шага", ylabel="Ошибка, логарифмическая шкала", title="Шаг обучения меняет поведение")
ax.legend(); fig.tight_layout(); fig.savefig(FIGURES / "P08_learning_rate.png", dpi=130); plt.show()
print("Нулевые значения отображены на уровне 1e-14 только для логарифмического графика.")
'''),('Обучить линейную модель', '''
x, y = [0, 1, 2], [1, 3, 5]
dw, db = linear_gradient(x, y, 0, 0)
print("Первый шаг:", -0.1*dw, -0.1*db)
result = fit_gradient(x, y, learning_rate=0.1, steps=500)
print({k:v for k,v in result.items() if k != "history"}, "final MSE:", result["history"][-1])
assert result["history"][-1] < 1e-10
bad = fit_gradient(x, y, learning_rate=10)
assert bad["status"] == "diverged"
print("Большой шаг:", bad["status"], "записано значений:", len(bad["history"]))
''')],
"guided":"Восстановите вручную два первых шага scalar-примера. В линейном примере объясните, почему оба параметра меняются одновременно.",
"task":"Для x=[0,1], y=[2,5], w=b=0 рассчитайте градиент и один шаг с learning_rate=0.1. Затем реализуйте собственный цикл с историей ошибки и остановкой при нечисловых значениях или резком росте. CLI может проверить linear_gradient из вашего файла: --task gradient.",
"solution":'''x_new, y_new = [0, 1], [2, 5]
dw, db = linear_gradient(x_new, y_new, 0, 0)
next_w, next_b = -0.1*dw, -0.1*db
np.testing.assert_allclose([dw, db], [-5, -7])
np.testing.assert_allclose([next_w, next_b], [0.5, 0.7])
trained = fit_gradient(x_new, y_new, learning_rate=0.1, steps=1000)
np.testing.assert_allclose([trained["w"], trained["b"]], [3, 2], atol=1e-5)
print("Первый шаг:", next_w, next_b, "параметры после обучения:", trained["w"], trained["b"])''',
"rubric":"Градиент (-5,-7), первый шаг (.5,.7); обновление использует минус; история содержит реальную ошибку; расходимость распознаётся и не объявляется успешным обучением.",
"starter_rubric":"Градиент выведен из функции ошибки и проверен центральной разностью; первый шаг рассчитан из исходных параметров и learning_rate; обновление использует минус; история содержит реальную ошибку; расходимость распознаётся и не объявляется успешным обучением.",
"retry":"Измените только learning_rate. Объясните, почему больше шаг не обязательно быстрее приводит к решению.",
"source":"https://developers.google.com/machine-learning/crash-course/linear-regression/hyperparameters",
},
{
"id":"P09", "title":"Воспроизводимый эксперимент", "goal":"Разделить train/validation/test, выбрать модель по validation и сравнить с baseline.",
"before":"P03 о независимой проверке, P08 о параметрах; новый термин baseline — простое исходное решение.",
"explanation":"100 синтетических примеров имеют известный генератор, но добавленный шум не позволяет получить нулевую ошибку простой линией. Генератор и seed фиксируют повторяемость. Модель выбирается по validation; test используется после выбора. Результат относится только к этой учебной постановке.",
"examples":[('Прочитать фиксированные данные', '''
frame = pd.read_csv(ROOT / "data" / "pilot" / "regression.csv")
display(frame.head(6).round(4))
print(frame.groupby("split").size().to_dict())
assert len(frame) == 100
assert frame["row_id"].is_unique
assert frame.groupby("split").size().to_dict() == {"test":20, "train":60, "validation":20}
'''),('Обучить исходное и линейное решения', '''
from sklearn.linear_model import LinearRegression
train = frame[frame["split"] == "train"]
validation = frame[frame["split"] == "validation"]
test = frame[frame["split"] == "test"]
baseline = train["y"].mean()
model = LinearRegression().fit(train[["x"]], train["y"])
validation_scores = {"baseline": mse(validation["y"], np.full(len(validation), baseline)),
                     "linear": mse(validation["y"], model.predict(validation[["x"]]))}
chosen = min(validation_scores, key=validation_scores.get)
test_prediction = (model.predict(test[["x"]]) if chosen == "linear" else np.full(len(test), baseline))
report = run_experiment()
assert chosen == report["selected_on_validation"]
assert np.isclose(mse(test["y"], test_prediction), report["test_mse"], atol=1e-10)
print(json.dumps(report, ensure_ascii=False, indent=2))
'''),('Посмотреть данные и ошибки', '''
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
for name, color, marker in [("train", "#1f5a99", "o"), ("validation", "#b56c19", "s"), ("test", "#555555", "x")]:
    subset = frame[frame["split"] == name]
    axes[0].scatter(subset["x"], subset["y"], s=24, color=color, marker=marker, label=name)
grid = np.linspace(-2, 2, 100)
axes[0].plot(grid, model.coef_[0]*grid + model.intercept_, color="#333333", linestyle="--", label="Модель")
axes[0].set(xlabel="x, условные единицы", ylabel="y, условные единицы", title="Синтетические данные и модель")
axes[0].legend(fontsize=9)
axes[1].scatter(test_prediction, test["y"].to_numpy()-test_prediction, color="#1f5a99", s=25)
axes[1].axhline(0, color="#555555", linestyle="--")
axes[1].set(xlabel="Предсказание", ylabel="y − предсказание", title="Ошибки на 20 тестовых примерах")
fig.tight_layout(); fig.savefig(FIGURES / "P09_experiment.png", dpi=130); plt.show()
''')],
"guided":"Назовите строку, где выбирается модель. Покажите, что в этой строке нет test. Сравните отчёт с повторным запуском.",
"task":"Повторите эксперимент на новой синтетической задаче с noise=0.7 и тем же seed. Сначала зафиксируйте план выбора. Сравните baseline и линейную модель по validation, затем один раз измерьте test. Разберите три самых крупных ошибки и объясните, почему нельзя перенастраивать модель после просмотра test.",
"solution":'''new_report = run_experiment(seed=2026, noise=0.7)
print(json.dumps(new_report, ensure_ascii=False, indent=2))
new_data = pd.DataFrame(make_dataset(seed=2026, noise=0.7))
new_test = new_data[new_data["split"] == "test"].copy()
new_test["prediction"] = predict_line(new_test["x"], **new_report["parameters"])
new_test["absolute_error"] = abs(new_test["prediction"] - new_test["y"])
display(new_test.nlargest(3, "absolute_error")[["row_id", "x", "y", "prediction", "absolute_error"]].round(5))
assert new_report["counts"] == {"train":60, "validation":20, "test":20}
print("Повышенный шум — новая учебная постановка. Test не превращаем в набор настройки.")''',
"rubric":"Разделение 60/20/20 неизменно; baseline учится на train; выбор по validation; test не влияет на выбор; вывод ограничен данной задачей.",
"retry":"Предложите способ получить более устойчивую оценку без многократной подгонки к одному test. Объясните отличие проверки гипотезы от её генерации по тестовым ошибкам.",
"source":"https://scikit-learn.org/stable/common_pitfalls.html",
},
{
"id":"P10", "title":"Защита эксперимента и архитектуры", "goal":"Объяснить эксперимент, границы качества и план восстановления сервиса на новой ситуации.",
"before":"Все предыдущие занятия. Защита проверяет объяснение и перенос, а не только исполнение ячеек.",
"explanation":"Технический отчёт фиксирует данные, разделение, baseline, правило выбора и итоговую проверку. Архитектурный отчёт добавляет входы, версию артефакта, место метрик и способ отката. Наличие работающего кода ещё не доказывает независимого понимания автора.",
"examples":[('Собрать факты для защиты', '''
report = run_experiment()
summary = {"dataset": "synthetic_regression_v1", "seed":2026,
           "split":report["counts"], "selected_on":"validation",
           "model":report["selected_on_validation"], "test_mse":report["test_mse"],
           "baseline_test_mse":report["test_baseline_mse"],
           "learner_mastery":"not_assessed"}
print(json.dumps(summary, ensure_ascii=False, indent=2))
''')],
"guided":"По готовому отчёту восстановите порядок действий, не читая код. Назовите минимум одну границу вывода.",
"task":"Защитите собственную работу P09: постановка, происхождение данных, метрика, независимость test, три ошибки и границы. Затем выполните перенос на новый фиксированный набор: seed=2027, noise=0.7, x uniform(-2,2), 100 примеров, permutation и split 60/20/20 как в make_dataset. Сначала зафиксируйте выбор по validation, потом измерьте test. Нарисуйте сервис, который использует сохранённые параметры; объясните rollback модели вместе с преобразованием. Смена диапазона входов на [-3,3] — дополнительный устный сценарий, а не замена нового набора.",
"solution":'''transfer_report = run_experiment(seed=2027, noise=0.7)
assert transfer_report["counts"] == {"train":60, "validation":20, "test":20}
print(json.dumps(transfer_report, ensure_ascii=False, indent=2))
defense_reference = {
    "scope": "Искусственная линейная зависимость с шумом; результат не переносится автоматически на интервью.",
    "experiment": "Train обучает, validation выбирает, test оценивает после выбора.",
    "architecture": "Валидация входа → преобразование конкретной версии → параметры → ответ + версия.",
    "shift": "Проверить новую выборку входов [-3,3]; выделить экстраполяцию и не заявлять прежнюю ошибку.",
    "rollback": "Сохранить и совместно вернуть модель, преобразования и схему входа.",
    "next": "Собрать независимые примеры нужной рабочей задачи и заранее определить критерии."
}
print(json.dumps(defense_reference, ensure_ascii=False, indent=2))
print("Эталон — ориентир аргументации. Он не является результатом защиты ученика.")''',
"rubric":"Ученик восстанавливает логику и отвечает на новый сценарий; нет утечки, причинных обещаний по игрушечным данным и смешения технического запуска с владением навыком.",
"retry":"Через интервал провести новую защиту на другом наборе данных или ином ограничении сервиса. Запись прогресса заполняет наставник по реальным ответам.",
"source":"https://scikit-learn.org/stable/model_selection.html",
},
]


for lesson in LESSONS:
    for kind, destination in [("starter", "notebooks"), ("solution", "solutions")]:
        identifier = lesson["id"]
        notebook = nbf.v4.new_notebook()
        notebook.metadata = {
            "kernelspec":{"display_name":"Python 3", "language":"python", "name":"python3"},
            "language_info":{"name":"python", "version":"3.11"},
            "mlcourse":{"lesson_id":identifier, "kind":kind, "version":"0.1.0", "data":"synthetic", "mastery":"not_assessed"},
        }
        cells = [md(f"# {identifier} {lesson['title']}\n\n**{'Эталон решения' if kind == 'solution' else 'Рабочий ноутбук'}**. Полное объяснение находится в Pages. Этот файл содержит исполняемый практикум."),
                 md(f"## Цель\n\n{lesson['goal']}\n\n**Перед началом:** {lesson['before']}"),
                 md("## Подготовка\n\nЗапускайте из корня репозитория в его виртуальном окружении. Первичная установка зависимостей описана в README. После установки выполнение не использует сеть, платные API или GPU."),
                 code(SETUP), md(f"## Разобранный пример\n\n{lesson['explanation']}")]
        for label, content in lesson["examples"]:
            cells += [md(f"### {label}"), code(content)]
        cells += [md(f"## Практика с поддержкой\n\n{lesson['guided']}"),
                  md(f"## Самостоятельная задача\n\n{lesson['task']}\n\nСначала выполните свою попытку. Подсказки и разбор доступны у наставника; использованную помощь отмечайте.")]
        if kind == "solution":
            cells += [md("### Эталон\n\nОткрывайте после собственной попытки. После разбора понадобится новый вариант для проверки самостоятельности."), code(lesson["solution"])]
        else:
            cells += [code("# Здесь ваша реализация или расчёт.\n# Ячейка намеренно не содержит готового решения и не ломает запуск примеров."),
                      md("**Ваше объяснение:** замените этот абзац своим рассуждением, результатом и ограничением. Это поле для ответа ученика, а не пропущенное объяснение автора.")]
        rubric = lesson.get("starter_rubric", lesson["rubric"]) if kind == "starter" else lesson["rubric"]
        cells += [md(f"## Проверка\n\n{rubric}\n\nУспешный Run All подтверждает запуск подготовленных примеров. Самостоятельная работа и понимание требуют отдельной проверки наставником."),
                  md(f"## Следующий шаг\n\n{lesson['retry']}\n\n[Основной источник]({lesson['source']}). Все значения в примерах синтетические. Сохраняйте исходные ноутбуки; для своей работы используйте копию.")]
        notebook.cells = cells
        nbf.validate(notebook)
        path = ROOT / destination / "pilot" / f"{identifier}.ipynb"
        path.parent.mkdir(parents=True, exist_ok=True)
        nbf.write(notebook, path)

data_dir = ROOT / "data" / "pilot"
data_dir.mkdir(parents=True, exist_ok=True)
pd.DataFrame(make_dataset()).to_csv(data_dir / "regression.csv", index=False, float_format="%.17g")
(data_dir / "provenance.json").write_text(json.dumps({
    "dataset_id":"synthetic_regression_v1", "created_for":"ML/LLM course pilot", "seed":2026,
    "generator":"mlcourse.pilot.make_dataset", "rows":100,
    "formula":"rng=default_rng(2026); x=uniform(-2,2,100); y=2*x+1+normal(0,.35,100); order=rng.permutation(100)",
    "split":"first60 shuffled ids train, next20 validation, final20 test",
    "license":"CC0-1.0 for these author-generated synthetic rows", "real_person_data":False,
    "limitation":"Teaching illustration only; no evidence about interview performance or hiring."
}, ensure_ascii=False, indent=2), encoding="utf-8")
inventory = [{"id":l["id"], "notebook":f"notebooks/pilot/{l['id']}.ipynb", "solution":f"solutions/pilot/{l['id']}.ipynb", "requires":["CPU", "Python3.11"], "status":"authored", "source":l["source"]} for l in LESSONS]
(ROOT / ".authoring" / "pilot_lab_inventory.json").write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8")
(ROOT / ".authoring" / "experiment_expected.json").write_text(json.dumps({"noise_035":run_experiment(), "noise_07":run_experiment(noise=.7), "transfer_P10":run_experiment(seed=2027, noise=.7)}, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"Authored {len(LESSONS)*2} notebooks and synthetic data")
