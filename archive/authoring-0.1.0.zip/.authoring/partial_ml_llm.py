import full_ml_llm as author
from pathlib import Path
for name in ['ml_systems_content.py','torch_content.py','nlp_content.py','llm_content.py','rag_complete.py','eval_content.py']:
    path=Path(__file__).parent/name
    if path.exists():
        exec(compile(path.read_text(encoding='utf-8'),name,'exec'),vars(author))
print([(x['id'],x['words']) for x in author.LESSONS])
