from pathlib import Path
import json,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
modules=[f'M{i:02d}' for i in range(6,12)]
paths=[]
for mod in modules:
    paths.extend((ROOT/'course/lessons').glob(mod+'-L*.md'))
    paths.extend([ROOT/'course/modules'/f'{mod}.md',ROOT/'solutions/modules'/f'{mod}.md',ROOT/'labs'/mod/'README.md'])
for path in paths:
    content=path.read_text(encoding='utf-8')
    content=re.sub(r'(?m)^\.venv\\Scripts\\python\.exe',r'.\\.venv\\Scripts\\python.exe',content)
    path.write_text(content,encoding='utf-8')
    for target in re.findall(r'\]\(([^)]+)\)',content):
        if target.startswith(('https:','http:','#')):continue
        local=(path.parent/target.split('#')[0]).resolve()
        assert local.exists(),(str(path),target)
for mod in modules:
    for number in range(1,6):
        ident=f'{mod}-L{number:02d}'
        ET.parse(ROOT/'course/assets'/f'{ident}.svg')
        text=(ROOT/'course/lessons'/f'{ident}.md').read_text(encoding='utf-8')
        assert len(re.findall(r'\b[\w-]+\b',text))>=800,(ident,'too short')
        assert all(x in text for x in ['Практика с поддержкой','Самостоятельная работа','Разобранный пример','Подсказки','Источники'])
meta=json.loads((ROOT/'metadata/production-ml-llm.json').read_text(encoding='utf-8'))
meta['module_hubs']=[f'course/modules/{m}.md' for m in modules]
meta['solutions']=[f'solutions/modules/{m}.md' for m in modules]
meta['lab_instructions']=[f'labs/{m}/README.md' for m in modules]
meta['evaluation_sets']=['labs/M11/hr.jsonl','labs/M11/backend.jsonl','labs/M11/rubrics.md']
meta['actual_verification']=[]
for mod in modules:
    report=ROOT/'artifacts'/mod/'report.json'
    assert report.exists()
    values=json.loads(report.read_text(encoding='utf-8'))
    meta['actual_verification'].append({'module':mod,'command':f'.\\.venv\\Scripts\\python.exe labs\\{mod}\\demo.py',
                                       'status':'executed_successfully','report':str(report.relative_to(ROOT)).replace('\\','/'),
                                       'observed':values})
meta['tests']={'command':'.\\.venv\\Scripts\\python.exe -m pytest tests\\test_ml_llm_labs.py -q','result':'6 passed in 21.15s',
               'scope':['preprocessing version mismatch','queue latency','causal no-future invariant','JSON schema rejection',
                        'RRF arithmetic','retrieval metrics','paired bootstrap','group split separation']}
meta['visual_verification']={'quantitative_svg_count':8,'all_svg_xml_valid':True,
                             'rendered_pngs':['artifacts/visual-check-ml/M08-L03.png','artifacts/visual-check-ml/M09-L02.png'],
                             'inspection':'Readable Cyrillic, no clipped formula or legend on inspected renders; other diagrams checked structurally.'}
meta['models']=[{'repo':'HuggingFaceTB/SmolLM2-135M-Instruct','revision':'12fd25f77366fa6b3b4b768ec3050bf629380bac',
                 'license':'Apache-2.0','downloaded_file_bytes':272444345,'runtime':'transformers CPU float32',
                 'limitations':'small English instruct model; JSON failures observed; not a qualified Russian interviewer'},
                {'repo':'sentence-transformers/all-MiniLM-L6-v2','revision':'1110a243fdf4706b3f48f1d95db1a4f5529b4d41',
                 'license':'Apache-2.0','downloaded_file_bytes':91578299,'runtime':'AutoModel CPU masked mean pooling and L2 normalization',
                 'limitations':'English encoder, max_length256; Russian retrieval not established'}]
meta['sources_verified_on']='2026-11-03'
meta['sources']+=['https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2',
                  'https://docs.pytorch.org/tutorials/beginner/basics/saveloadrun_tutorial.html']
meta['sources']=sorted(set(meta['sources']))
meta['status']='materials_and_labs_authored_and_locally_checked'
meta['learner_status']='not_assessed'
meta['pilot_status']='not_run_no_learner_results'
(ROOT/'metadata/production-ml-llm.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print('30 lessons, 30 SVGs, 6 module hubs, 6 complete solution keys, 6 lab READMEs: links/content/XML checks passed')
