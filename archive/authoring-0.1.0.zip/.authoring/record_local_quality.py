from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import sys

root=Path(__file__).resolve().parents[1]
registry=json.loads((root/'metadata/material-registry.json').read_text(encoding='utf-8'))
manifest=json.loads((root/'course-manifest.json').read_text(encoding='utf-8'))
notebooks=json.loads((root/'artifacts/notebook-validation.json').read_text(encoding='utf-8'))
assert len(registry)==36
assert manifest['delivery']['status']=='local_ready'
assert len(notebooks['records'])==20 and all(x['status']=='executed' for x in notebooks['records'])
report={
 'version':'0.2.0','recorded_at_utc':datetime.now(timezone.utc).isoformat(),
 'scope':'Local self-study delivery of existing curriculum and ten ready sessions',
 'python':sys.version.split()[0],
 'checks':{
  'pytest':{'passed':49,'failed':0,'command':'.venv/Scripts/python.exe -m pytest -q'},
  'notebooks':{'executed':20,'failed':0,'report':'artifacts/notebook-validation.json'},
  'manifest_delivery':'local_ready','local_materials':36,'curriculum_modules':17,'curriculum_lessons':85,
  'reader_freshness':'passed','local_links_and_anchors':'passed',
  'notebook_code_changed':False,'starter_outputs_saved':False,
  'launcher':'START_PRACTICE.cmd --check passed from another working directory',
  'browser':{
   'engine':'Microsoft Edge via Playwright','transport':'file URL with offline context',
   'desktop_viewport':[1440,1000],'mobile_viewport':[390,844],
   'checked':['Home to diagnostics to P01 navigation','Full-text search and reset','No search results',
    'Hints closed then opened and closed','Answer key closed then opened and closed',
    'Mobile menu and navigation','Readable mobile heading and body','Print button beforeprint event',
    'Print CSS hides navigation and shows one current material','Unknown hash falls back to home'],
   'page_errors':[],'external_asset_requests':[],
   'visual_review':'Desktop and mobile screenshots inspected; no stable clipping or horizontal document overflow',
   'artifacts':['artifacts/reader-desktop.jpg','artifacts/reader-mobile-stable.png','artifacts/reader-hints.png'],
   'print_limit':'Print UI event and CSS checked; no physical print job or PDF exported'
  }
 },
 'repairs':['Local Markdown became canonical; old remote addresses are provenance only',
  'Removed required mentor submission and added self-check progression',
  'Rebased relative links in executed notebook copies',
  'Fixed heading level so hints collapse without hiding the next assessment',
  'Normalized canonical Markdown and registry to LF for Git-stable fingerprints'],
 'states':{'full_course_ready':False,'learner_mastery':'not_assessed','career_readiness':'not_assessed',
           'learner_progress':'progress/progress.md','voice_product':'requirements_only'},
 'sha256':{item['path']:sha256((root/item['path']).read_bytes()).hexdigest() for item in registry.values()}
}
report['sha256']['START_HERE.html']=sha256((root/'START_HERE.html').read_bytes()).hexdigest()
(root/'quality/release-0.2.0.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Recorded local release evidence: 36 materials, 49 tests, 20 notebooks')
