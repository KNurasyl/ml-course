"""One-time migration; canonical local Markdown is edited directly afterwards."""
import hashlib
import json
from pathlib import Path
import posixpath
import re

ROOT = Path(__file__).resolve().parents[1]
imported = {p['key']: p for p in json.loads((ROOT/'.authoring/imported-course.json').read_text(encoding='utf-8'))}
paths = {'HOME':'course/README.md','DIAGNOSTIC':'course/diagnostic.md','GLOSSARY':'course/glossary.md',
         'PROJECT':'course/project.md','MENTOR':'course/self-study.md','MENTOR-KEYS':'solutions/pilot/answer-key.md',
         'PROGRESS':'progress/progress.md','REF-CATALOG':'course/references/catalog.md','REF-METHOD':'course/references/methodology.md'}
paths.update({f'M{i:02}':f'course/modules/M{i:02}.md' for i in range(17)})
paths.update({f'P{i:02}':f'course/pilot/P{i:02}.md' for i in range(1,11)})
url_keys = {p['url']:k for k,p in imported.items()}

def local_link(key, target):
    return posixpath.relpath(paths[target], posixpath.dirname(paths[key]))

def nested_headings(text):
    lines, in_fence = [], False
    for line in text.splitlines():
        if line.startswith(('```','~~~')):
            in_fence = not in_fence
        if not in_fence and re.match(r'^#{1,5} ',line):
            line = '#' + line
        lines.append(line)
    return '\n'.join(lines)

replacements = {
 'Текстовые ответы и рассуждения проверяет наставник: успешный запуск ноутбука сам по себе не подтверждает понимание.':
 'Проверь текстовые ответы и рассуждения по критериям и ключу после своей попытки. Успешный запуск ноутбука сам по себе не подтверждает понимание. Порядок самопроверки описан в руководстве по самостоятельному обучению.',
 'Одну строку проверь с наставником, остальные заполни сам.':'Одну строку повторно пересчитай вручную и сравни с кодом, остальные заполни сам.',
 'Сдай схему, таблицу четырёх входных случаев и описание отказа.':'Сохрани схему, таблицу четырёх входных случаев и описание отказа в своей работе.',
 'вернись к выводу с наставником.':'вернись к разобранному выводу; при затруднении используй подсказки и затем новый пример.',
 'Сдай вычисления, код проверки, выбранный шаг и объяснение допустимой разницы.':'Сохрани вычисления, код проверки, выбранный шаг и объяснение допустимой разницы.',
 'Сначала за пять минут объясни задачу человеку, который не видел ноутбук.':'Сначала запиши пятиминутное устное объяснение или короткий текст так, чтобы его понял человек, который не видел ноутбук.',
 'Наставник должен понять, когда были доступны':'По твоему объяснению должно быть понятно, когда были доступны',
 'Наставник предлагает ситуацию:':'Самостоятельно разбери ситуацию:',
 'Подсказки выдаются по уровню:':'Используй подсказки по уровню:',
 'До запуска запиши ожидание о влиянии более сильного шума.':'До запуска запиши ожидание о влиянии шума 0.7 по сравнению с разобранной практикой P09, где шум был 0.35. По сравнению с самостоятельной работой P09-HW01 шум остаётся прежним, меняется seed.',
 'Сдать один текстовый документ с нумерованными ответами и небольшой файл кода.':'Сохрани один текстовый документ с нумерованными ответами и небольшой файл кода.',
 'Наставник сопоставляет самооценку с выполнением, но не выводит общий «уровень интеллекта».':'После первой попытки сопоставь самооценку с ключом. Общий балл не нужен: отметь конкретные пробелы.',
 'После диагностики наставник отмечает конкретные предпосылки для восстановления и выбирает ближайшее упражнение.':'После самопроверки отметь конкретные предпосылки для восстановления и выбери следующий шаг по таблице ниже.',
 'Материал для наставника и последующей самопроверки.':'Ключи для самостоятельной проверки после собственной попытки.',
 'Сдать код или расчёты, наблюдаемый результат и объяснение решения.':'Сохранить код или расчёты, наблюдаемый результат и объяснение решения.',
 'Эта страница содержит паспорт модуля':'Этот файл содержит паспорт модуля',
 'на этой странице составлены':'в этом материале составлены',
 'на отдельной странице ключей':'в отдельном файле ключей',
 'На занятие предусмотрено около четырёх часов вместе с перерывами':'Начальный ориентир занятия — около четырёх часов вместе с перерывами',
 'Не сравнивай скорость своей работы со временем преподавателя:':'Записывай собственное время и не торопись:',
}

def convert(key):
    source = imported[key]
    text = source['markdown']
    for url,target in url_keys.items():
        text = text.replace(url,local_link(key,target))
    if key.startswith('REF-'):
        note = '**Справочный снимок исследования от 3 ноября 2026 года.** Это каталог источников и методические основания. Актуальный порядок самостоятельного прохождения задан в [оглавлении](../README.md); прежние рекомендации по сопровождению не являются обязательным условием.\n\n'
        text = note + text
    else:
        text = text.replace('0.1.0','0.2.0')
        for old,new in replacements.items():
            text = text.replace(old,new)
    if re.fullmatch(r'P\d{2}',key):
        text = text.replace(f'Практический файл: notebooks/pilot/{key}.ipynb.',f'Практический файл: [ноутбук {key}](../../notebooks/pilot/{key}.ipynb).')
        text = text.replace(f'solutions/pilot/{key}.ipynb',f'[эталоном {key}](../../solutions/pilot/{key}.ipynb)')
        text = text.replace('с [эталоном','с [эталоном')
        number = int(key[1:])
        links = ['[Оглавление](../README.md)','[Как учиться самостоятельно](../self-study.md)','[Словарь](../glossary.md)']
        if number>1: links.append(f'[Предыдущее занятие](P{number-1:02}.md)')
        if number<10: links.append(f'[Следующее занятие](P{number+1:02}.md)')
        text += '\n\n# После своей попытки\n\nСверь расчёты и объяснения с [ключами решений](../../solutions/pilot/answer-key.md), выполни новый вариант и запиши результат в [журнал](../../progress/progress.md). Отметь, была ли содержательная помощь. Это самопроверка; независимая оценка по желанию может быть выполнена позже.\n\n'+' · '.join(links)
    if re.fullmatch(r'M\d{2}',key):
        text += '\n\n[Вернуться к оглавлению](../README.md) · [Самостоятельный порядок работы](../self-study.md)'
    if key=='DIAGNOSTIC':
        text += '''

# Самопроверка и выбор следующего шага

Сначала сохрани все ответы, затем открой [ключи диагностики](../solutions/pilot/answer-key.md). Для каждого пункта отметь: получилось без помощи; получилось с помощью; нужно повторение. Текст и вычисления можно вести в обычном редакторе, Jupyter необязателен.

| Где возникло затруднение | Что сделать |
| --- | --- |
| 1–2: подстановка и линейная функция | Прочитай разобранный пример [P01](pilot/P01.md), подставь x=0,1,2 в 3x+2 и проверь, что получились 2,5,8. Затем реши самостоятельную задачу P01 без подсказки. |
| 3–4: среднее, медиана, логарифм | Среднее: сумма, делённая на количество. Медиана: середина отсортированного ряда. log₂(8)=3 означает 2³=8. Вернись к подробному восстановлению в M04; незнание логарифма не блокирует P01. |
| 5–6 и 10: векторы и формы | Начни с P01; перед матричной практикой пройди объяснение [P04](pilot/P04.md). |
| 7: изменение функции | Разберёшь на числах в [P07](pilot/P07.md); вывод производной не требуется для первого занятия. |
| 8: неопределённость | Зафиксируй вопрос для M04. Совпадение долей ещё не означает равенства неопределённости. |
| 9: Python-функция ошибки | В [P02](pilot/P02.md) сначала составь таблицу вручную, затем перенеси те же действия в цикл. |
| 11: архитектура | Используй минимальный путь вход → проверка → обработка → ответ; в [P05](pilot/P05.md) добавятся параметры модели и версии. |
| 12: модель и обучение | Это исходная диагностика; объяснение начинается в [P01](pilot/P01.md). |

Не жди проверки в чате: после фиксации результатов переходи к P01. Если сохраняется конкретное противоречие с эталоном, сначала открой подсказку; разбор с человеком или AI доступен по желанию.
'''
    return '# '+source['title']+'\n\n'+nested_headings(text)+'\n'

registry = {}
for key,path in paths.items():
    title=imported[key]['title']
    if key=='MENTOR':title='Как учиться самостоятельно'
    if key=='HOME':title='ML и LLM: локальный самоучитель'
    if key=='MENTOR-KEYS':title='Ключи решений для самопроверки'
    status='introductory_draft' if re.fullmatch(r'M\d{2}',key) else 'reference_snapshot' if key.startswith('REF-') else 'ready'
    registry[key]={'id':key,'title':title,'path':path,'version':'0.2.0','status':status}
    if key not in {'HOME','MENTOR','PROGRESS'}:
        target=ROOT/path
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(convert(key),encoding='utf-8')
(ROOT/'metadata/material-registry.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
archive={key:{'source_id':p['id'],'source_url':p['url'],'source_title':p['title'],
              'imported_sha256':hashlib.sha256(p['markdown'].encode()).hexdigest(),
              'local_path':paths[key],'role':'historical_source_only'} for key,p in imported.items()}
(ROOT/'metadata/source-pages.json').write_text(json.dumps(archive,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Migrated {len(paths)-3} documents; registry has {len(registry)} materials. HOME/MENTOR/PROGRESS authored separately.')
