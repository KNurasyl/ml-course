from pathlib import Path
import ast, contextlib, io, json, os, re, sys
sys.stdout.reconfigure(encoding='utf-8')
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0,str(ROOT))
fixes={'заканчиваетсяуспехом':'заканчивается успехом','однозадачногоадаптера':'однозадачного адаптера','недоступнуюмодель':'недоступную модель','неизвестнуюсессию':'неизвестную сессию','отсутствиефинала':'отсутствие финала','пустойввод':'пустой ввод','повторныйзапрос':'повторный запрос','остановкузвука':'остановку звука','новыйнабор':'новый набор','итоговыйвывод':'итоговый вывод'}
checks=[]
for mod in range(12,17):
    paths=list((ROOT/'course/lessons').glob(f'M{mod}-*.md'))+[ROOT/'course/modules'/f'M{mod}.md',ROOT/'solutions/modules'/f'M{mod}.md']
    for path in paths:
        text=path.read_text(encoding='utf-8')
        for old,new in fixes.items():text=text.replace(old,new)
        path.write_text(text,encoding='utf-8',newline='\n')
        if path.parent.name!='lessons':continue
        for n,code in enumerate(re.findall(r'```python\s*\n(.*?)```',text,re.S),1):
            output=io.StringIO()
            with contextlib.redirect_stdout(output):
                exec(compile(code,str(path)+f':block{n}','exec'),{})
            checks.append({'lesson':path.stem,'block':n,'status':'passed','stdout':output.getvalue()[:1500]})
        for target in re.findall(r'\]\(([^)]+)\)',text):
            if '://' in target or target.startswith('#'):continue
            target=target.split('#')[0]
            if target:assert (path.parent/target).resolve().exists(),(path,target)
    for path in (ROOT/f'labs/M{mod}').glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
meta_path=ROOT/'metadata/production-ops-voice.json'
meta=json.loads(meta_path.read_text(encoding='utf-8'))
meta['checks']=checks
for item in meta['lessons']:
    text=(ROOT/item['path']).read_text(encoding='utf-8')
    item['words']=len(re.findall(r'\b[А-Яа-яЁёA-Za-z]+\b',re.sub(r'```.*?```','',text,flags=re.S)))
meta['actual_verification']={'date':'2026-11-03','python':'3.11.9','torch':'2.15.0+cpu','vosk':'0.3.45','labs':['M12','M13','M14','M15','M16'],'pytest':'tests/test_ops_voice.py: 11 passed','homework_solutions':['M12_hw.py: mixed old loss 0.5040496588, new 1.0053714514','M14_hw.py: 10 expected paths passed'],'speech':'SAPI Microsoft Irina Desktop → mono PCM16 16kHz → Vosk small-ru-0.22; WER2/7; real run, one synthetic voice sample','docker':'optional; not executed','human_pilot':'not performed or inferred by author','python_lesson_blocks':len(checks)}
meta_path.write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8',newline='\n')
print(json.dumps({'python_blocks_passed':len(checks),'lesson_links':'all exist','min_words':min(x['words'] for x in meta['lessons'])},ensure_ascii=False))
