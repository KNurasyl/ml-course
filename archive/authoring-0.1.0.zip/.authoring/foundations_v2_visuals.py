from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from math import comb
from labs.M04.bridges import plan
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':13})
out=ROOT/'course/assets';out.mkdir(exist_ok=True)

fig,axes=plt.subplots(1,3,figsize=(12,3.7),constrained_layout=True)
x=np.linspace(-2,2,200);axes[0].plot(x,np.exp(x));axes[0].scatter([0],[1]);axes[0].set(title='exp(x)=eˣ',xlabel='x',ylabel='Результат')
x=np.linspace(.04,4,200);axes[1].plot(x,np.log(x));axes[1].scatter([1],[0]);axes[1].set(title='ln(x): только x>0',xlabel='x',ylabel='Показатель степени')
p=np.linspace(.01,1,200);axes[2].plot(p,-np.log(p));axes[2].scatter([.01,.5,.9],-np.log([.01,.5,.9]),color='#b75330');axes[2].set(title='Потеря −ln(p)',xlabel='Вероятность фактического исхода p',ylabel='Потеря')
for a in axes:a.grid(alpha=.2)
fig.savefig(out/'M04-L06.png',dpi=160);plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(11,4),constrained_layout=True)
seq={k:[] for k in range(5)}
for n in range(16):
 s=f'{n:04b}';seq[s.count('1')].append(s)
axes[0].axis('off');axes[0].set_title('Последовательности с одинаковым X')
for k in range(5):axes[0].text(.04+k*.19,.8,f'X={k}\n'+'\n'.join(seq[k]),ha='center',va='top',fontsize=12,family='monospace')
prob=np.array([comb(4,k)/16 for k in range(5)])
axes[1].bar(range(5),prob,color=['#417b75']*3+['#bc7745']*2)
axes[1].set(title='P(X≥3) = 4/16 + 1/16 = 5/16',xlabel='Число успехов X',ylabel='Вероятность',xticks=range(5),ylim=(0,.44))
for k,v in enumerate(prob):axes[1].text(k,v+.01,f'{comb(4,k)}/16',ha='center')
fig.savefig(out/'M04-L07.png',dpi=160);plt.close(fig)

fig,ax=plt.subplots(figsize=(9,4),constrained_layout=True)
for alt,label in [(.7,'Полезный эффект +0.10'),(.65,'Полезный эффект +0.05')]:
 rows=plan(p1=alt,sizes=(50,100,200,400,800));ax.plot([r['n'] for r in rows],[r['exact_power'] for r in rows],marker='o',label=label)
ax.axhline(.8,color='#b75330',linestyle='--',label='Требование мощности 0.8');ax.set(xlabel='Независимые наблюдения n',ylabel='Мощность при предположении',ylim=(0,1.04),title='Известный baseline p₀=0.6; односторонний exact test, α=0.05');ax.legend();ax.grid(alpha=.2)
fig.savefig(out/'M04-L08.png',dpi=160);plt.close(fig)

def svg(name,title,body):
 (out/f'{name}.svg').write_text(f'''<svg xmlns="http://www.w3.org/2000/svg" width="960" height="520" viewBox="0 0 960 520" role="img" aria-labelledby="title"><title id="title">{title}</title><rect width="960" height="520" fill="#f5f7ee"/><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0L8,4L0,8" fill="#356d62"/></marker></defs><g font-family="Arial,sans-serif" fill="#243c35" font-size="21"><text x="30" y="42" font-size="26">{title}</text>{body}</g></svg>''',encoding='utf-8')
svg('M05-L06','Обучение, выбор и независимая оценка', '''
<rect x="30" y="85" width="230" height="85" fill="#deead9"/><text x="50" y="120">Train</text><text x="50" y="150">Только train → fit</text>
<path d="M260,127H350" stroke="#356d62" stroke-width="3" marker-end="url(#arrow)"/>
<rect x="365" y="85" width="550" height="85" fill="#deead9"/><text x="385" y="120">Медианы → масштаб → категории → веса</text><text x="385" y="150">Один Pipeline для каждого C</text>
<rect x="30" y="220" width="230" height="85" fill="#e8dfc4"/><text x="50" y="255">Validation</text><text x="50" y="285">Выбор C и порога</text>
<path d="M260,262H350" stroke="#356d62" stroke-width="3" marker-end="url(#arrow)"/>
<rect x="365" y="220" width="550" height="85" fill="#e8dfc4"/><text x="385" y="255">Таблица стоимости: (2FN + FP) / N</text><text x="385" y="285">Фиксируем модель и порог до test</text>
<path d="M30,345H915" stroke="#ad573c" stroke-width="3" stroke-dasharray="9 6"/>
<rect x="30" y="385" width="230" height="85" fill="#dbe4ee"/><text x="50" y="420">Test</text><text x="50" y="450">только predict</text>
<path d="M260,427H350" stroke="#356d62" stroke-width="3" marker-end="url(#arrow)"/>
<rect x="365" y="385" width="550" height="85" fill="#dbe4ee"/><text x="385" y="420">Ошибки и ограничения выбранного решения</text><text x="385" y="450">Нет обратной стрелки к выбору</text>''')
svg('M05-L07','Группы и время: два ограничения split', '''
<rect x="190" y="85" width="210" height="310" fill="#deead9"/><rect x="400" y="85" width="210" height="310" fill="#e8dfc4"/><rect x="610" y="85" width="280" height="310" fill="#dbe4ee"/>
<text x="240" y="115">Train: day &lt; 5</text><text x="425" y="115">Validation: 5…7</text><text x="670" y="115">Test: day ≥ 8</text>
<text x="30" y="185">Пользователь a</text><path d="M240,180H290" stroke="#356d62" stroke-width="4"/><circle cx="240" cy="180" r="8" fill="#356d62"/><circle cx="290" cy="180" r="8" fill="#356d62"/><text x="230" y="215">1</text><text x="285" y="215">2</text>
<text x="30" y="275">Пользователь b</text><path d="M335,270H470" stroke="#ad573c" stroke-width="4"/><circle cx="335" cy="270" r="8" fill="#ad573c"/><circle cx="470" cy="270" r="8" fill="#ad573c"/><text x="327" y="305">3</text><text x="465" y="305">6</text>
<text x="30" y="365">Пользователь c</text><path d="M660,360H710" stroke="#356d62" stroke-width="4"/><circle cx="660" cy="360" r="8" fill="#356d62"/><circle cx="710" cy="360" r="8" fill="#356d62"/><text x="653" y="390">8</text><text x="703" y="390">9</text>
<text x="40" y="450" fill="#ad573c">Группа b пересекла границу: обе строки в excluded.</text>
<text x="40" y="485">Политика исключения фиксируется до обучения и записывается в отчёт.</text>''')

visual=ROOT/'course/visuals'
def interactive(name,title,question,body,js):
 (visual/f'{name}.html').write_text(f'''<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title><style>body{{font:17px/1.6 Arial;background:#f5f7ee;color:#243c35;padding:20px}}main{{max-width:780px;margin:auto}}label{{display:block}}input{{width:100%}}pre{{white-space:pre-wrap;background:white;padding:16px}}button{{padding:9px;font:inherit}}table{{border-collapse:collapse}}td,th{{padding:8px;border:1px solid #b8c5b2}}</style><main><h1>{title}</h1><p>{question}</p>{body}<pre id="out" aria-live="polite"></pre><button id="reset">Исходное значение</button><p>Сначала предскажи результат, затем измени параметр и объясни расхождение. Это численный опыт, не измерение качества интервьюера.</p></main><script>{js}</script></html>''',encoding='utf-8')
interactive('M04-L06','Вероятность и логарифмическая потеря','Предскажи: во сколько раз изменится потеря, если вероятность уменьшится вдвое? Это не линейная зависимость.','<label>p для класса 1: <input id="p" type="range" min="0.01" max="0.99" step="0.01" value="0.8"></label><label>Истинный класс <select id="y"><option value="1">1</option><option value="0">0</option></select></label>', '''const p=document.querySelector('#p'),y=document.querySelector('#y'),out=document.querySelector('#out');function draw(){let prob=+p.value,actual=y.value==='1'?prob:1-prob;out.textContent=`p(класс 1)=${prob.toFixed(2)}\nВероятность фактического класса=${actual.toFixed(2)}\nL=−ln(${actual.toFixed(2)})=${(-Math.log(actual)).toFixed(6)}\nПри уменьшении вероятности фактического класса вдвое потеря добавляет ln(2)≈0.693147.`;}p.oninput=y.onchange=draw;document.querySelector('#reset').onclick=()=>{p.value=.8;y.value='1';draw()};draw();''')
interactive('M05-L06','Порог и стоимость ошибок','Модель и вероятности зафиксированы. Меняется ли обучение весов, когда ты двигаешь порог?','<p>y=[1,0,1,0], p=[0.4,0.3,0.8,0.6]. Правило p≥порог.</p><label>Порог <input id="t" type="range" min="0.05" max="0.95" step="0.05" value="0.5"></label><label>Цена FN <input id="cost" type="range" min="1" max="5" step="1" value="2"></label>', '''const t=document.querySelector('#t'),cost=document.querySelector('#cost'),out=document.querySelector('#out');function draw(){let p=[.4,.3,.8,.6],y=[1,0,1,0],pred=p.map(v=>v>=+t.value?1:0),fn=y.filter((v,i)=>v===1&&pred[i]===0).length,fp=y.filter((v,i)=>v===0&&pred[i]===1).length;out.textContent=`Порог=${(+t.value).toFixed(2)}\nРешения=[${pred}]\nFN=${fn}; FP=${fp}\nСтоимость=(${cost.value}×${fn}+${fp})/4=${((+cost.value*fn+fp)/4).toFixed(3)}\nВеса и вероятности не менялись.`;}t.oninput=cost.oninput=draw;document.querySelector('#reset').onclick=()=>{t.value=.5;cost.value=2;draw()};draw();''')
print('5 figures and 2 interactive experiments written')
