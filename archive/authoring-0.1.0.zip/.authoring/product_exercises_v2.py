from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def write(path,text):
 p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text.strip()+'\n',encoding='utf-8')

items={
'M13':('choose_release','previous, candidate, checks', '''def choose_release(previous, candidate, checks):
    required = {'schema', 'canary', 'regressions'}
    if set(checks) != required or any(value is not True for value in checks.values()):
        return previous
    if candidate.get('schema') != previous.get('schema'):
        return previous
    return candidate
''', '''a={'version':'A','schema':1};b={'version':'B','schema':1}
    assert module.choose_release(a,b,{'schema':True,'canary':True,'regressions':True})==b
    assert module.choose_release(a,b,{'schema':True,'canary':False,'regressions':True})==a
    assert module.choose_release(a,dict(b,schema=2),{'schema':True,'canary':True,'regressions':True})==a
    assert module.choose_release(a,b,{'schema':True,'canary':True})==a
    assert module.choose_release(a,b,{'schema':True,'canary':1,'regressions':True})==a
''','candidate','Выбери целый релиз только после трёх независимых проверок schema/canary/regressions. Все значения — именно bool True; отсутствие проверки и несовместимый schema оставляют previous. Не изменяй словари. Это компонент приёмки; HTTP-измерения выполняются отдельно.'),
'M14':('parse_action','raw, allowed_ids', '''import json
def parse_action(raw, allowed_ids):
    try: value=json.loads(raw)
    except (ValueError,TypeError): raise ValueError('invalid_json')
    if not isinstance(value,dict) or set(value)!={'tool','args'} or value['tool']!='read_document':
        raise ValueError('action_schema')
    args=value['args']
    if not isinstance(args,dict) or set(args)!={'document_id'} or not isinstance(args['document_id'],str):
        raise ValueError('args_schema')
    if args['document_id'] not in allowed_ids:raise ValueError('not_available')
    return value
''', '''good='{"tool":"read_document","args":{"document_id":"manual-v2"}}'
    assert module.parse_action(good,{'manual-v2'})['args']['document_id']=='manual-v2'
    invalid=['x','[]','{"tool":"delete","args":{}}',good.replace('manual-v2','private'),
             '{"tool":"read_document","args":{"document_id":true}}',
             '{"tool":"read_document","args":{"document_id":"manual-v2","session":"admin"}}']
    for raw in invalid:
        try: module.parse_action(raw,{'manual-v2'})
        except ValueError:pass
        else:raise AssertionError('unsafe proposal accepted: '+raw)
''',"{'tool':'read_document','args':{'document_id':'manual-v2'}}",'Разбери raw JSON. Разрешён только read_document и ровно один строковый document_id из server allowed_ids. Любой лишний ключ, неверный тип, чужой ID, массив или неверный JSON должен вызвать ValueError до чтения. allowed_ids не берётся из raw.'),
'M15':('playable','events', '''def playable(events):
    active=0;queue=[];played=[]
    for kind,turn,payload in events:
        if kind=='begin':
            if turn<=active:raise ValueError('turn must increase')
            active=turn;queue=[]
        elif kind=='receive':
            if turn==active:queue.append((turn,payload))
        elif kind=='cancel':
            active+=1;queue=[]
        elif kind=='play':
            if queue:
                owner,chunk=queue.pop(0)
                if owner==active:played.append(chunk)
        else:raise ValueError('unknown event')
    return played
''', '''events=[('begin',5,None),('receive',5,'A'),('cancel',5,None),('receive',5,'B'),('play',0,None),
            ('begin',7,None),('receive',7,'C'),('play',0,None)]
    assert module.playable(events)==['C']
    assert module.playable([('begin',1,None),('receive',1,'A'),('play',0,None),('receive',1,'B'),('play',0,None)])==['A','B']
    assert module.playable([('begin',1,None),('receive',1,'A'),('begin',2,None),('play',0,None)])==[]
''',"[e[2] for e in events if e[0]=='receive']",'Обработай последовательность begin/receive/cancel/play. begin задаёт возрастающий номер эпохи и очищает очередь; cancel увеличивает эпоху и очищает очередь; receive принимает только активную эпоху; play берёт первый разрешённый фрагмент. Верни список действительно допущенных к воспроизведению payload. Аудио здесь не исполняется.'),
'M16':('transition','state, answer, limit', '''def transition(state, answer, limit):
    if type(limit) is not int or limit<0 or state['topic']>=state['topics']:raise ValueError('invalid state/limit')
    if not isinstance(answer,str) or len(answer.strip())<3:raise ValueError('invalid answer')
    out=dict(state);out['turn']+=1
    refusal=any(word in answer.lower() for word in ('не хочу','пропуст','отказываюсь'))
    incomplete=len(answer.strip())<80 or 'не знаю' in answer.lower()
    if incomplete and not refusal and state['clarifications']<limit:out['clarifications']+=1
    else:out['topic']+=1;out['clarifications']=0
    return out
''', '''s={'topic':0,'turn':0,'clarifications':0,'topics':5};original=dict(s)
    a=module.transition(s,'Пока не знаю.',2)
    assert a==dict(s,turn=1,clarifications=1) and s==original
    b=module.transition(a,'Пока не знаю.',2);c=module.transition(b,'Пока не знаю.',2)
    assert (c['topic'],c['turn'],c['clarifications'])==(1,3,0)
    assert module.transition(s,'Не хочу отвечать.',2)['topic']==1
    assert module.transition(s,'Коротко',0)['topic']==1
    count=0
    while s['topic']<5:s=module.transition(s,'Не знаю.',2);count+=1;assert count<=15
    assert count==15
    try:module.transition(s,'Ещё ответ',2)
    except ValueError:pass
    else:raise AssertionError('finished session accepted an answer')
''',"dict(state,turn=state['turn']+1,topic=state['topic']+1,clarifications=0)",'Новая политика: state содержит topic, turn, clarifications, topics; на тему разрешено limit уточнений. Короткий (<80 символов) или «не знаю» вызывает уточнение пока есть бюджет; отказ («не хочу», «пропуст», «отказываюсь») переводит далее сразу. После бюджета тема меняется. Функция чистая, завершённая сессия и недопустимый ответ отклоняются ValueError. Вариант отличается от bool-политики эталона: limit=2 и пять тем.')}

for m,(fn,args,solution,checks,mutant,description) in items.items():
 write(f'exercises/{m}/starter.py',f'"""Самостоятельная реализация. Контракт в README.md."""\ndef {fn}({args}):\n    raise NotImplementedError("Реализуй контракт после собственной попытки")')
 write(f'solutions/exercises/{m}/solution.py',solution)
 checker=f'''"""Validate the student's behavior, not filenames. No model or internet required."""
import argparse
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

def check(module):
    {checks.strip()}
    return True

def load(path):
    spec=importlib.util.spec_from_file_location('student_exercise',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('submission',type=Path);parser.add_argument('--self-test',action='store_true');args=parser.parse_args()
    check(load(args.submission))
    if args.self_test:
        bad=SimpleNamespace({fn}=lambda {args}: {mutant})
        try:check(bad)
        except (AssertionError,ValueError):pass
        else:raise AssertionError('checker failed to detect deliberately wrong implementation')
    print(json.dumps({{'behavior_passed':True,'mutant_rejected':args.self_test,'mastery':'not_assessed'}}))
'''
 write(f'exercises/{m}/check.py',checker)
 write(f'exercises/{m}/README.md',f'''# {m}: самостоятельный компонент

Версия 1.1.0. {description}

Скопируй starter.py в submissions/{m}/my_solution.py, реализуй функцию и сохрани объяснение решения. Не открывай готовый solution до первой попытки.

```powershell
.\.venv\Scripts\python.exe exercises\{m}\check.py submissions\{m}\my_solution.py
```

Проверка возвращает behavior_passed; самостоятельность и понимание она не определяет. При ошибке сократи свой пример и объясни нарушенный контракт. Стартовый файл намеренно не проходит проверку.

После попытки: [полное решение](../../solutions/exercises/{m}/solution.py). Проверка ключа и чувствительности к намеренному дефекту:

```powershell
.\.venv\Scripts\python.exe exercises\{m}\check.py solutions\exercises\{m}\solution.py --self-test
```

Новый пример после просмотра решения приведён в соответствующем новом уроке и ключе модуля. Нельзя считать повторный запуск этого же ключа самостоятельным результатом.
''')

write('solutions/exercises/M16/persistence.py','''"""Reference for a single-process local state snapshot, not a multiwriter database."""
import json
import os
from pathlib import Path

def save(path, state):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    payload={'schema':1,'state':state}
    temporary=path.with_suffix(path.suffix+'.tmp')
    with temporary.open('w',encoding='utf-8') as stream:
        json.dump(payload,stream,ensure_ascii=False);stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)

def restore(path):
    payload=json.loads(Path(path).read_text(encoding='utf-8'))
    if set(payload)!={'schema','state'} or payload['schema']!=1:raise ValueError('unsupported snapshot')
    state=payload['state']
    required={'mode','turn','topic','clarifications','history'}
    if not isinstance(state,dict) or set(state)!=required:raise ValueError('state schema')
    if state['mode'] not in ('hr','backend') or any(type(state[k]) is not int or state[k]<0 for k in ('turn','topic','clarifications')):
        raise ValueError('state values')
    if not isinstance(state['history'],list) or len(state['history'])!=state['turn']:raise ValueError('history mismatch')
    return state

def accept_turn(state, turn):
    if type(turn) is not int or turn != state['turn']:raise ValueError('stale turn')
    return True
''')
print('Four starter/checker/solution contracts and atomic snapshot example authored.')
