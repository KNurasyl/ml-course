"""Prepare evidence-backed lab READMEs and the M00--M05 production inventory."""
from pathlib import Path
import datetime,hashlib,json,platform,re
from importlib.metadata import version
from PIL import Image,ImageOps,ImageDraw

ROOT=Path(__file__).resolve().parents[1]
verification=json.loads((ROOT/'metadata/foundations-verification.json').read_text(encoding='utf-8'))
assert not verification['failures'],verification['failures']
versions={name:version(name) for name in ['numpy','pandas','scipy','scikit-learn','matplotlib']}
curriculum=json.loads((ROOT/'curriculum.json').read_text(encoding='utf-8'))
lessons=[];labs=[];sources=set();total_words=0
summaries={
'M00':'MSE кандидатов A=0 и B=1.5; выбран A, ответ для x=4 равен 13. Пять типов неверного входа отклонены. Проверяется различие параметров, входа и артефакта.',
'M01':'6 исходных строк → 5 после удаления точной копии; train=3, test=2; среднее train=4, преобразованный test=[6,10]. После добавления 100 прежние ответы неизменны. Среднее по сессиям 20, наивное среднее после JOIN 15.',
'M02':'Запрос q1 возвращает A,B; q2 — C,B. Средние recall@1=0.75 и recall@2=1. Проверяются размерность, нулевые/нечисловые представления, границы k и порядок при равенстве оценок.',
'M03':'Без штрафа w≈3,b≈1,MSE≈0. С λ=0.5 получены w≈2.4,b≈1,MSE≈0.72,штраф≈2.88,сумма≈3.6. Аналитический градиент проверяется независимыми центральными разностями; дублирование набора не меняет средний градиент.',
'M04':'Доли A=0.5,B=0.75,парный эффект 0.25. Bootstrap-интервал [0,0.625], исходных независимых сессий 8, вычислительных повторов 20000. Нетождественных пар 2, знаковый p=0.5. Формула Уилсона сверена со SciPy в шести случаях, включая границы.',
'M05':'Сравниваются средний прогноз, линейная модель, два дерева и бустинг. Выбор использует только validation. На зафиксированном синтетическом наборе выбран boosting; ниже приведены реальные локальные измерения, а не обещание результата на пользовательских интервью.'}

for module in curriculum['modules'][:6]:
    mid=module['id'];run=next(r for r in verification['results'] if r['path'].replace('\\','/')==f'labs/{mid}/demo.py')
    observed=json.loads((ROOT/f'labs/{mid}/output/result.json').read_text(encoding='utf-8'))
    table=''
    if mid=='M05':
        table='\n| Модель | Validation MAE | Validation MSE |\n|---|---:|---:|\n'
        for row in observed['validation']:
            table+=f"| {row['model']} | {row['validation_mae']:.6f} | {row['validation_mse']:.6f} |\n"
        table+=f"\nВыбранная модель: **{observed['selected_by_validation_only']}**. Test MAE={observed['test_mae']:.6f}, MSE={observed['test_mse']:.6f}. Test не используется для выбора строки таблицы. Срез x<0: n=32,MAE=0.189840; x≥0: n=28,MAE=0.241947. Это наблюдения на синтетике, без вывода о готовности продукта.\n"
    readme=f'''# {mid}. Локальная лабораторная

**Цель:** воспроизвести вычисления модуля «{module['title']}», проверить содержательные инварианты и затем самостоятельно решить изменённый вариант.

## Запуск в Windows PowerShell

Открой терминал и выполни команды по порядку. Первая команда задаёт рабочую папку: относительный путь к Python отсчитывается от неё.

```powershell
Set-Location C:\\projects\\ml-llm-course
.\\.venv\\Scripts\\python.exe labs\\{mid}\\demo.py
```

При успешном выполнении программа печатает JSON, создаёт каталог `output` рядом с `demo.py` и заканчивает с кодом 0. Если окружение ещё не подготовлено, используй [общую инструкцию](../../README.md). Активация venv не требуется, потому что указан путь к его Python.

## Данные и ресурсы

Данные авторские и синтетические: они заданы непосредственно в скрипте либо создаются фиксированным генератором. Чужих разговоров, резюме и персональных данных нет. Интернет, платный API, GPU, Docker и загрузка модели для этой лабораторной не требуются. Достаточно CPU; для учебных массивов разумно иметь 1 ГБ свободной RAM. Это запас для окружения, а не измеренный пик памяти.

Проверено в Python {platform.python_version()} на Windows, с numpy {versions['numpy']}, pandas {versions['pandas']}, scipy {versions['scipy']}, scikit-learn {versions['scikit-learn']}. Полный состав окружения зафиксирован в [requirements.lock.txt](../../requirements.lock.txt). Необязательные пакеты всего курса могут отсутствовать в конкретном скрипте.

## Ожидаемый результат и наблюдённая проверка

{summaries[mid]}
{table}
Последний локальный проверочный запуск: **{run['seconds']:.3f} с**, код возврата **{run['returncode']}**. Время зависит от нагрузки, холодного импорта и компьютера; оно не является гарантией задержки сервиса. [Полный измеренный результат](output/result.json).

Числа с плавающей точкой сравниваются с допуском, а не текстовым совпадением всех знаков. Где используется случайность, seed и размеры зафиксированы в коде. Изменение seed может изменить статистический результат; не меняй данные ради совпадения с желаемой метрикой.

## Как выполнить самостоятельно

1. Прочитай пять уроков из [оглавления модуля](../../course/modules/{mid}.md) и реши короткие задачи.
2. До запуска запиши ожидаемые ключевые числа и возможную ошибку контракта.
3. Запусти пример, сопоставь вывод с ручным расчётом и проверь, какой assert обнаруживает содержательную ошибку.
4. Создай свой файл в `submissions/{mid}` и выполни {mid}-HW01 из оглавления, затем новый вариант.
5. Открой [ключи](../../solutions/modules/{mid}.md) после собственной попытки. Укажи использованную помощь и повтори задачу с другими условиями.

`demo.py` — эталонный исполняемый пример, поэтому его запуск не засчитывает самостоятельное выполнение. Для самопроверки важны объяснение, собственный вариант и обработка неверного входа, а не наличие файла с правильным названием.

## Проверка всего фундамента

```powershell
.\\.venv\\Scripts\\python.exe tools\\check_foundations.py
```

Проверка выполняет Python-блоки уроков и решений, затем шесть CPU-лабораторных. Подробный журнал: [foundations-verification.json](../../metadata/foundations-verification.json). Это техническая проверка материалов; учебный прогресс она не изменяет.
'''
    readme=readme.replace(',MAE',', MAE').replace(',b=',', b=').replace(',MSE',', MSE').replace(',штраф',', штраф').replace(',сумма',', сумма').replace(',парный',', парный')
    (ROOT/f'labs/{mid}/README.md').write_text(readme,encoding='utf-8',newline='\n')
    labs.append({'module':mid,'path':f'labs/{mid}/demo.py','readme':f'labs/{mid}/README.md','result':f'labs/{mid}/output/result.json','observed_seconds':run['seconds'],'returncode':run['returncode']})
    for rec in module['lessons']:
        key=rec['id'];path=ROOT/f'course/lessons/{key}.md';text=path.read_text(encoding='utf-8')
        words=len(re.findall(r'[А-Яа-яЁё]+(?:[-–][А-Яа-яЁё]+)*',text));total_words+=words
        figure=ROOT/f'course/assets/{key}.png';assert figure.exists()
        sources.update(re.findall(r'https://[^)\s]+',text))
        lessons.append({'id':key,'path':str(path.relative_to(ROOT)).replace('\\','/'),'figure':str(figure.relative_to(ROOT)).replace('\\','/'),'russian_words':words,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'solution':f'solutions/modules/{mid}.md'})

# Review sheets are derived QA artifacts, not new teaching figures.
qa=ROOT/'.authoring'/'foundation-qa';qa.mkdir(exist_ok=True)
for start in [0,15]:
    sheet=Image.new('RGB',(1500,1500),'white')
    for index,rec in enumerate(lessons[start:start+15]):
        im=Image.open(ROOT/rec['figure']).convert('RGB');im=ImageOps.contain(im,(500,280))
        x=(index%3)*500;y=(index//3)*300
        sheet.paste(im,(x,y));ImageDraw.Draw(sheet).text((x+10,y+281),rec['id'],fill='black')
    sheet.save(qa/f'contact-{start//15+1}.jpg',quality=90)

metadata={'scope':'M00-M05','material_status':'authored_and_locally_executed','learner_skill_status':'not_assessed','pilot_status':'not_substituted_by_author_checks','generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'lesson_count':len(lessons),'russian_words':total_words,'lessons':lessons,'labs':labs,'figure_count':30,'figure_generator':'.authoring/foundations_visuals.py','versions':{'python':platform.python_version(),**versions},'sources':[{'url':url,'verification':'opened primary documentation with web tool','date':'2026-11-03'} for url in sorted(sources)],'observed_verification':{'command':'.venv\\Scripts\\python.exe tools\\check_foundations.py','passed':verification['passed'],'failures':verification['failures'],'log':'metadata/foundations-verification.json'},'visual_review':{'method':'rendered PNGs and contact sheets; representative full-size plots inspected','contact_sheets':['.authoring/foundation-qa/contact-1.jpg','.authoring/foundation-qa/contact-2.jpg']},'limits':['Synthetic toy experiments do not establish real interview quality.','Author execution does not certify learner independence.','No paid API, GPU, network download, or external dataset is required for M00-M05.']}
(ROOT/'metadata/production-foundations.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'lessons':len(lessons),'figures':30,'labs':len(labs),'words':total_words,'verified_cases':verification['passed']},ensure_ascii=False))
