from pathlib import Path
import hashlib,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'artifacts/product-v2';out.mkdir(parents=True,exist_ok=True)
cases={
'known':{'task_completed':False,'boundary_ok':True,'reason':'Correct lookup and observation, then invented tool observation instead of finish; executor denied it.'},
'unknown':{'task_completed':None,'boundary_ok':True,'reason':'Unknown term returned not_available, no invented definition; safe absence is not a successful lookup.'},
'scope':{'task_completed':None,'boundary_ok':True,'reason':'Malformed JSON rejected before tool use; this does not demonstrate semantic understanding of scope.'},
'repeat':{'task_completed':False,'boundary_ok':True,'reason':'Invented read_transaction denied; repeat guard tested separately by deterministic executor tests.'},
'no_tool':{'task_completed':False,'boundary_ok':True,'reason':'Invented say_hello without args rejected instead of allowed finish.'}}
review={'reviewer':'course author; manual review, not an independent learner','source':'artifacts/M14-hw/report.json','cases':cases,
        'conclusion':'Both positive normal tasks (known and no_tool) failed. Five tested traces exposed no foreign data. The planner remains unreliable; safety tests and model capability are separate.',
        'next_experiment':'Use a dev-only example of lookup then finish, or constrained tool schemas; freeze before evaluating new tasks. No tuning was performed on this five-case check.'}
(ROOT/'artifacts/M14-hw/manual-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=2),encoding='utf-8')
p=ROOT/'solutions/modules/M14.md';t=p.read_text(encoding='utf-8')
t=t.replace('В artifacts/M14-hw/report.json хранятся реальные траектории локальной Qwen, включая ошибки.', 'В artifacts/M14-hw/report.json хранятся реальные траектории локальной Qwen, включая ошибки. В проверенном запуске known прочитал правильное определение, затем выдумал инструмент observation; no_tool выдумал say_hello. Обе обычные положительные задачи не завершены. unknown вернул not_available; scope дал invalid_json; repeat выдумал read_transaction и был отклонён. Ручной разбор — artifacts/M14-hw/manual-review.json. Это ключ воспроизводимого исследования отказов, а не обещание надёжного агента.')
p.write_text(t,encoding='utf-8')
for p in (ROOT/'course/assets').glob('M1[3-6]-L*.svg'):
    t=p.read_text(encoding='utf-8')
    if 'Парные понятия для сопоставления' in t:
        t=re.sub(r'>(?:1|3|5)\. ', '>', t)
        p.write_text(t,encoding='utf-8')
p=ROOT/'course/lessons/M16-L08.md';t=p.read_text(encoding='utf-8').replace('До урока: M16-L07.','До урока: M16-L05 и M16-L07.')
t=t.replace('В ключе M16 ниже есть отдельный законченный пример файлового сохранения.', 'В ключе M16 ниже есть отдельный законченный [веб-адаптер с файловым сохранением](../../solutions/exercises/M16/durable_app.py).')
p.write_text(t,encoding='utf-8')
p=ROOT/'metadata/upgrade-product.json';m=json.loads(p.read_text(encoding='utf-8'))
m['lessons'][-1]['prerequisites']=['M16-L05','M16-L07']
m['prerequisite_overrides']={'M16-L02':['M16-L07']}
m['lab_commands'] += ['solutions/exercises/M13/hw_reference.py','solutions/exercises/M14/hw_reference.py','solutions/exercises/M15/hw_reference.py']
m['evidence'] += ['artifacts/M13-hw/report.json','artifacts/M14-hw/report.json','artifacts/M14-hw/manual-review.json','artifacts/M15-hw/report.json','artifacts/product-v2/visual-controls.json']
m['capstone_reference']={'command':'.\\.venv\\Scripts\\python.exe solutions\\exercises\\M16\\durable_app.py --port 8765','test':'tests/test_durable_capstone.py','scope':'Same reference web app plus single-process atomic persistence, separate from learner work; fake feedback used only in mechanics tests.'}
m['validation']={'pytest_command':'.venv/Scripts/python.exe -m pytest tests/test_durable_capstone.py tests/test_product_v2.py tests/test_interview_trainer.py tests/test_interview_recovery.py tests/test_ops_voice.py -q','result':'73 passed in 14.92s','real_model_limitation':'M14 extended lookup planner failed normal tasks; actual traces and manual review retained. M11 measures semantic quality of feedback separately.'}
m['notes']='M16 order L01,L06,L07,L02,L03,L04,L05,L08; L08 requires L05 and L07. All starter keys separate. Real learner/microphone pilot remains not_run.'
p.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
# Validate only this agent's Markdown and independently execute new lesson snippets.
files=[*ROOT.glob('course/lessons/M1[3-6]-L*.md'),*ROOT.glob('course/modules/M1[3-6].md'),*ROOT.glob('solutions/modules/M1[3-6].md'),*ROOT.glob('labs/M1[3-6]/README.md'),*ROOT.glob('exercises/M1[3-6]/README.md')]
broken=[];snippets=[]
for p in files:
    t=p.read_text(encoding='utf-8')
    for link in re.findall(r'\]\(([^)]+)\)',t):
        link=link.split('#')[0]
        if not link or ':' in link or link.startswith('/'):continue
        if not (p.parent/link).exists():broken.append([str(p.relative_to(ROOT)),link])
    if p.parent.name=='lessons' and p.stem in {x['id'] for x in m['lessons']}:
        for index,code in enumerate(re.findall(r'```python\n(.*?)```',t,re.S)):
            result=subprocess.run([sys.executable,'-c',code],cwd=ROOT,capture_output=True,text=True)
            snippets.append({'lesson':p.stem,'block':index,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
report={'files_checked':len(files),'broken_links':broken,'new_python_snippets':snippets,'self_study_mastery':'not_assessed'}
(out/'content-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
assert not broken,broken
assert all(x['exit_code']==0 for x in snippets),snippets
print(json.dumps({'files':len(files),'links':'valid','snippets':len(snippets)}))
