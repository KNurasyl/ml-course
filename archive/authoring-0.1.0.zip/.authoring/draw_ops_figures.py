from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'course/assets'
PREVIEW=ROOT/'.authoring/ops-previews'
PREVIEW.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'svg.fonttype':'none',
                     'axes.spines.top':False,'axes.spines.right':False,
                     'figure.facecolor':'#f4f7fb','axes.facecolor':'#f4f7fb'})

def save(fig, ident):
    fig.savefig(ASSETS/f'{ident}.svg',bbox_inches='tight',metadata={'Title':ident,'Description':'Авторская учебная визуализация; источники чисел указаны в уроке.'})
    fig.savefig(PREVIEW/f'{ident}.png',dpi=110,bbox_inches='tight')
    plt.close(fig)

fig,axes=plt.subplots(1,3,figsize=(12,4),gridspec_kw={'width_ratios':[1,3,3]})
A=np.array([[1],[0],[-1],[2]])
B=np.array([[0,1,2]])
for ax,array,title in zip(axes,[A,B,A@B],['A: 4 × 1\n4 параметра','B: 1 × 3\n3 параметра','ΔW = A @ B: 4 × 3\n12 элементов, ранг ≤ 1']):
    ax.imshow(array,cmap='RdBu',vmin=-4,vmax=4,aspect='auto')
    for (i,j),v in np.ndenumerate(array):ax.text(j,i,str(v),ha='center',va='center',fontsize=19)
    ax.set_title(title,pad=14)
    ax.set_xticks([]);ax.set_yticks([])
fig.suptitle('M12-L04 · Обучаем 7 чисел, получаем добавку к 12 весам',fontsize=17,y=1.08)
fig.text(.5,-.02,'Все строки ΔW кратны B. Ранг не равен числу выученных фактов.',ha='center')
fig.tight_layout()
save(fig,'M12-L04')

fig,ax=plt.subplots(figsize=(11,5))
x=np.arange(2);w=.32
ax.bar(x-w/2,[.166378,3.731763],w,label='База',color='#28775b')
ax.bar(x+w/2,[11.989497,.566252],w,label='Адаптер rank 1',color='#bc5b28')
ax.set_yscale('log');ax.set_ylim(.1,20)
ax.set_xticks(x,['Старая грамматика ab','Новая грамматика ac'])
ax.set_ylabel('Независимая cross entropy\nлогарифмическая шкала, меньше лучше')
ax.set_title('M12-L05 · Новая задача улучшилась, старая резко ухудшилась')
ax.legend();ax.grid(axis='y',alpha=.2)
for xi,values in zip([x-w/2,x+w/2],[[.166378,3.731763],[11.989497,.566252]]):
    for xx,v in zip(xi,values):ax.text(xx,v*1.12,f'{v:.3f}',ha='center')
fig.text(.5,-.02,'Фактический CPU-запуск: seed 17, PyTorch 2.15.0+cpu. Это синтетическая биграммная задача.',ha='center',fontsize=10)
fig.tight_layout();save(fig,'M12-L05')

fig,ax=plt.subplots(figsize=(11,5))
queue=np.array([0]*16+[900]*4);base=np.full(20,500)
ax.bar(np.arange(1,21),base,label='ASR 200 + генерация 300 мс',color='#28775b')
ax.bar(np.arange(1,21),queue,bottom=base,label='Очередь 900 мс',color='#bc5b28')
ax.axhline(680,color='#276bd1',linestyle='--',label='Среднее 680 мс')
ax.axhline(1400,color='#7957bc',linestyle=':',label='p95 = 1400 мс')
ax.set_xticks([1,5,10,15,20]);ax.set_xlabel('Номер запроса');ax.set_ylabel('Полная задержка, мс')
ax.set_ylim(0,1800);ax.legend(ncol=2,fontsize=10)
ax.set_title('M13-L04 · Очередь объясняет хвост задержки')
fig.text(.5,-.02,'Учебные заданные числа; не замер скорости реального интервьюера.',ha='center',fontsize=10)
fig.tight_layout();save(fig,'M13-L04')

fig,axes=plt.subplots(1,2,figsize=(12,4))
rate=16000;t=np.arange(320)/rate;y=.7*np.sin(2*np.pi*220*t)
axes[0].plot(t*1000,y,color='#276bd1');axes[0].set_title('20 мс искусственного тона 220 Гц')
axes[0].set_xlabel('Время, мс');axes[0].set_ylabel('Нормированная амплитуда');axes[0].set_ylim(-1,1)
axes[1].stem(t[:20]*1000,y[:20],linefmt='#bc5b28',markerfmt='o',basefmt='k-')
axes[1].set_title('Отдельные отсчёты: шаг 1/16000 с');axes[1].set_xlabel('Время, мс');axes[1].set_ylim(-1,1)
fig.suptitle('M15-L01 · Дискретизация: измерения амплитуды во времени',fontsize=16,y=1.05)
fig.text(.5,-.06,'Это наглядный искусственный сигнал, не речь. PCM16: 2 байта на отсчёт; моно: 1 канал.',ha='center',fontsize=11)
fig.tight_layout();save(fig,'M15-L01')

fig,ax=plt.subplots(figsize=(12,4.5))
ax.set_xlim(0,5.5);ax.set_ylim(-.7,2.8)
ax.set_yticks([0,1,2],['Клиентский звук','Ход 12','Ход 11'])
ax.set_xticks([0,1,2,3,4,5],['t0','t1','t2','t3','t4','t5'])
ax.set_xlabel('Порядок событий; шкала условная')
ax.barh(2,4,left=0,height=.25,color='#adbacb');ax.text(.1,2.25,'Долгое вычисление 11',fontsize=11)
ax.axvline(1,color='#bc5b28',linestyle='--');ax.text(1.05,2.55,'Отмена 11',color='#bc5b28')
ax.barh(1,1.4,left=1.4,height=.25,color='#28775b');ax.text(1.5,1.25,'Ответ 12 готов',fontsize=11)
ax.annotate('',xy=(2.8,0),xytext=(2.8,1),arrowprops={'arrowstyle':'->','color':'#28775b','lw':2})
ax.text(2.85,.1,'12 принят',color='#28775b')
ax.plot(4,2,'x',color='#bc5b28',markersize=14,mew=3)
ax.text(4.05,1.6,'Поздний 11\nотброшен',color='#bc5b28')
ax.set_title('M15-L04 · Поздний результат не должен оживить отменённый ход')
ax.grid(axis='x',alpha=.2);fig.tight_layout();save(fig,'M15-L04')

fig,ax=plt.subplots(figsize=(12,3.6));ax.axis('off')
for y,label,words in [(0.64,'Эталон',['я','не','использовал','docker']),(0.27,'Гипотеза',['я','∅','использовал','docker'])]:
    ax.text(.01,y+.05,label,fontsize=12)
    for i,word in enumerate(words):
        x=.2+i*.19
        ax.text(x,y,word,ha='center',va='center',fontsize=18,bbox={'boxstyle':'round,pad=.5','facecolor':'#f5d9ca' if i==1 else '#e0eaf5','edgecolor':'#bc5b28' if i==1 else '#276bd1'})
ax.set_title('M15-L05 · Одно удаление из четырёх слов меняет смысл',fontsize=17)
ax.text(.5,.02,'WER = 1 / 4 = 0,25. Пропуск отрицания — отдельная критическая ошибка.',ha='center',fontsize=13)
save(fig,'M15-L05')

fig,ax=plt.subplots(figsize=(11,5));ax.axis('off')
rows=[['Что оцениваем','HR','Техническое интервью'],['Содержание','Конкретное личное действие','Корректный технический факт'],['Обоснование','Почему выбрано действие','Компромиссы и ограничения'],['Проверка','Подтверждённый результат','План измерения / тест'],['Критическая ошибка','Приписанный опыт','Ложный факт или вывод']]
table=ax.table(cellText=rows,cellLoc='left',loc='center',colWidths=[.23,.36,.41])
table.auto_set_font_size(False);table.set_fontsize(11);table.scale(1,2.5)
for (r,c),cell in table.get_celld().items():
    cell.set_edgecolor('#c8d2df')
    cell.set_facecolor('#dce7f4' if r==0 else '#ffffff')
    if r==0:cell.set_text_props(weight='bold')
ax.set_title('M16-L01 · Две рубрики проверяют разные свойства',fontsize=17,pad=15)
fig.tight_layout();save(fig,'M16-L01')
print('7 specialized figures saved; previews in .authoring/ops-previews')
