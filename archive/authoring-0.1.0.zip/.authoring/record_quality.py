from datetime import datetime, timezone
from hashlib import sha256
from importlib.metadata import version
import json
from pathlib import Path
import platform
import sys

root = Path(__file__).resolve().parents[1]
report = json.loads((root / 'artifacts/notebook-validation.json').read_text(encoding='utf-8'))
manifest = json.loads((root / 'course-manifest.json').read_text(encoding='utf-8'))
assert len(report['records']) == 20
assert all(row['status'] == 'executed' for row in report['records'])
assert manifest['publication']['status'] == 'verified'
assert len(manifest['pages']) == 34
assert all(page['readback_verified'] for page in manifest['pages'].values())
paths = sorted([*root.glob('notebooks/pilot/*.ipynb'), *root.glob('solutions/pilot/*.ipynb'),
                *root.glob('src/mlcourse/*.py'), *root.glob('tests/*.py'), *root.glob('tools/*'),
                root/'requirements.lock.txt', root/'curriculum.json', root/'course-manifest.json'])
for path in root.glob('notebooks/pilot/*.ipynb'):
    notebook = json.loads(path.read_text(encoding='utf-8'))
    assert all(not cell.get('outputs') for cell in notebook['cells'])
evidence = {
    'version': '0.1.0',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'release_scope': 'curriculum_design_and_ten_session_pilot',
    'python': sys.version.split()[0],
    'platform': platform.platform(),
    'packages': {p: version(p) for p in ['numpy', 'pandas', 'matplotlib', 'scikit-learn', 'nbclient', 'jupyterlab', 'pytest']},
    'verification': {
        'main_environment': '.venv', 'clean_environment': '.venv-verify',
        'clean_install_command': 'powershell -NoProfile -ExecutionPolicy Bypass -File tools/bootstrap.ps1 -Environment .venv-verify',
        'clean_install_observed_exit_code': 0,
        'pip_check_observed_output': 'No broken requirements found.',
        'pytest_observed_passed': 36,
        'pytest_observed_failed': 0,
        'pytest_run_in_both_environments': True,
        'notebooks_executed_in_both_environments': 20,
        'clean_notebook_command': '.venv-verify/Scripts/python.exe tools/run_notebooks.py --kind all --html',
        'final_command': 'powershell -NoProfile -ExecutionPolicy Bypass -File tools/verify.ps1',
        'final_command_observed_exit_code': 0,
        'curriculum_validation_errors': [],
        'pages_created_and_read_back': 34,
        'source_starters_have_no_saved_outputs': True,
        'submissions_working_directory_checked_with': 'P01',
        'figure_inspection': ['P08_learning_rate.png', 'P09_experiment.png'],
        'page_visual_preview': 'not_verified; saved content and navigation were read back',
        'html_preview': '20 exports created; browser layout not separately reviewed',
    },
    'notebook_records': report['records'],
    'content_audit_repairs': [
        'Removed numeric homework answers from starter rubrics P01/P04/P08.',
        'Aligned P09 homework and mentor keys with seed=2026, noise=0.7.',
        'Assigned distinct retry and delayed-check conditions.',
        'Kept 85 designed lessons separate from 10 ready pilot sessions.',
    ],
    'limitations': {
        'full_course_ready': False,
        'learner_pilot': 'awaiting_learner',
        'learner_mastery': 'not_assessed',
        'career_readiness': 'not_assessed',
        'voice_product': 'requirements_only',
        'interview_data': 'synthetic_development_examples_not_independently_human_validated',
        'later_module_labs': 'not_yet_authored_or_verified',
    },
    'sha256': {p.relative_to(root).as_posix(): sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()},
}
target = root/'quality/release-0.1.0.json'
target.parent.mkdir(exist_ok=True)
target.write_text(json.dumps(evidence, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'file': str(target), 'tests':36, 'notebooks':20, 'pages':34, 'full_course_ready':False}))
