import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from projects.interview_trainer import app
class Fixture:
    model = None
    last_generation = {"input_tokens": 1, "output_tokens": 1, "truncated": False}
    def generate(self, messages):
        return "Фикстура интерфейса. Уточни результат своего действия. Это не ответ языковой модели."
app.MODEL = Fixture()
server = app.ThreadingHTTPServer(("127.0.0.1",8766),app.Handler)
print("Fixture UI server 8766",flush=True)
server.serve_forever()
