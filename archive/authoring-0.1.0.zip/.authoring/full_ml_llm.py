"""Authoring helper; outputs are canonical. Do not run unrelated archived scripts."""
from pathlib import Path
import json, html, re

ROOT=Path(__file__).resolve().parents[1]
CUR=json.loads((ROOT/'curriculum.json').read_text(encoding='utf-8-sig'))
MODULES={m['id']:m for m in CUR['modules']}
LESSONS=[]

def svg(identifier, title, rows, footer='Учебный пример: числа заданы для разбора механизма.'):
    """Diagram rows are (left label, right explanation), not decorative placeholders."""
    height=150+len(rows)*68
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1040 {height}" role="img" aria-labelledby="title"><title id="title">{html.escape(title)}</title><rect width="1040" height="{height}" fill="#f5f7fc"/><g font-family="Segoe UI,Arial,sans-serif"><text x="32" y="44" font-size="25" fill="#182b49">{html.escape(title)}</text>']
    for i,(a,b) in enumerate(rows):
        y=72+i*68
        parts.append(f'<rect x="30" y="{y}" width="300" height="54" rx="8" fill="#dde9fb"/><text x="44" y="{y+33}" font-size="19" fill="#15457e">{html.escape(a)}</text><path d="M340 {y+27}h28" stroke="#47749e" stroke-width="3"/><path d="M361 {y+21}l9 6-9 6" fill="none" stroke="#47749e" stroke-width="3"/><text x="385" y="{y+33}" font-size="18" fill="#182b49">{html.escape(b)}</text>')
    parts.append(f'<text x="32" y="{height-24}" font-size="16" fill="#536780">{html.escape(footer)}</text></g></svg>')
    path=ROOT/'course/assets'/f'{identifier}.svg';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(''.join(parts),encoding='utf-8')

def lesson(identifier, theory, worked, guided, task, hints, errors, solution, rows, sources, transfer):
    mod=identifier[:3];meta=next(x for x in MODULES[mod]['lessons'] if x['id']==identifier)
    title=meta['title'];svg(identifier,title,rows)
    previous=', '.join(meta['prerequisites'])
    text=f'''# {identifier}. {title}

**Результат:** {meta['assessment']}\n\n**До урока:** {previous}. Если термины из этих уроков не удаётся объяснить своими словами, вернись к их разобранным примерам. Ориентир времени — {meta['estimated_minutes']} минут чтения и практики; это первоначальная оценка, а не ограничение.

## Зачем и как это работает

{theory}

![{title}: численная схема](../assets/{identifier}.svg)

## Разобранный пример

{worked}

## Практика с поддержкой

{guided}

## Самостоятельная работа {identifier}-A

{task}

Первая попытка — без готового решения. Сохрани свой код, объяснение и фактический результат в `submissions/{identifier}/`. AI может пояснять термин и помогать найти ошибку; запиши полученную помощь. Прочитанное решение не означает самостоятельно выполненное задание.

## Подсказки по очереди

{hints}

## Ошибки и самопроверка

{errors}

Работа готова, когда есть ответ на все условия задачи, вычисление или наблюдение подтверждает вывод, а ты можешь объяснить каждую величину и изменить один параметр без копирования решения. Критическую ошибку сначала исправь и повтори проверку; оформление не компенсирует неверное рассуждение. Сверь свою попытку с [решением {identifier}-A](../../solutions/modules/{mod}.md).

## Повтор и перенос

{transfer}

После проверки сохрани статус «самостоятельно» либо «с поддержкой», конкретную ошибку и дату следующей попытки. Через 7–10 дней повтори изменённый пример без открытого решения; только эта проверка позволяет отметить «подтверждено позже». Если результата пока нет, оставь «не проверено».

## Источники и углубление

{chr(10).join('- ['+a+']('+b+')' for a,b in sources)}

Текст, численные примеры, задания и схемы этого урока созданы для данного курса. Источники нужны для проверки терминов и изучения исходного метода; они не заменяют самостоятельную практику.
'''
    p=ROOT/'course/lessons'/f'{identifier}.md';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8')
    LESSONS.append(dict(id=identifier,title=title,solution=solution,sources=sources,words=len(re.findall(r'\b[\w-]+\b',text))))

def hub(mod, introduction, homework, hwsolution, criteria, retry):
    meta=MODULES[mod];items=[x for x in LESSONS if x['id'].startswith(mod)]
    links='\n'.join(f"{i+1}. [{x['id']} — {x['title']}](../lessons/{x['id']}.md)" for i,x in enumerate(items))
    text=f'''# {mod}. {meta['title']}

{introduction}

## Порядок занятий

{links}

После каждого урока сначала выполни самостоятельную задачу. Открой решение только после своей попытки. Проходить весь модуль за один день не требуется: при 4–5 часах в день чередуй чтение, расчёты, программирование и воспроизведение по памяти.

## Лабораторная работа

[Инструкция и ресурсы](../../labs/{mod}/README.md). Из корня `C:\\projects\\ml-llm-course`:

```powershell
.venv\\Scripts\\python.exe labs\\{mod}\\demo.py
```

Код эталонной лабораторной показывает воспроизводимый эксперимент. Затем сделай собственную изменённую версию; успешный запуск эталона не является проверкой твоего навыка.

## {mod}-HW01 — самостоятельная работа

{homework}

## Рубрика

По каждому пункту поставь 0 — отсутствует/неверно, 1 — частично или после существенной помощи, 2 — полностью и самостоятельно. Все пункты обязательны; для зачёта самопроверки нужно 2 по каждому, затем отдельный перенос на новый случай.

{chr(10).join('- '+x for x in criteria)}

Критические ошибки: {', '.join(meta['homework']['critical_errors'])} При любой из них работа возвращается на исправление независимо от суммы баллов. Правильный код с неверным объяснением проверяет только запуск, но не понимание. Помощь отметь отдельно от правильности.

## Новая попытка и отложенная проверка

{retry}

Через 7–10 дней выполни повтор без открытого ключа. В итоговом проекте ещё раз проверь этот навык на новых входах и запиши ограничения переноса. Результаты и затраченное время внеси в локальный журнал прогресса.

## Решения

[Полный ключ пяти уроков и домашней работы](../../solutions/modules/{mod}.md). Ключ содержит один корректный вариант; эквивалентное обоснованное решение тоже допустимо.
'''
    (ROOT/'course/modules'/f'{mod}.md').write_text(text,encoding='utf-8')
    solved=f'# {mod}: решения для самопроверки\n\nОткрывай после собственной попытки. Если ты изучил ключ до решения, новая задача из раздела повторения обязательна для проверки самостоятельности. Числа в учебных примерах не являются оценкой реальных кандидатов.\n\n'
    solved+='\n\n'.join(f"## {x['id']}-A\n\n{x['solution']}" for x in items)
    solved+=f'\n\n## {mod}-HW01\n\n{hwsolution}\n'
    p=ROOT/'solutions/modules'/f'{mod}.md';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(solved,encoding='utf-8')

SYS=[('Stanford CS329S: ML systems','https://stanford-cs329s.github.io/'),('Google: Rules of ML','https://developers.google.com/machine-learning/guides/rules-of-ml')]
TORCH=[('PyTorch: основы','https://docs.pytorch.org/tutorials/beginner/basics/intro.html'),('PyTorch: autograd','https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html')]
ATT=[('Attention Is All You Need, исходная статья','https://arxiv.org/abs/1706.03762'),('Hugging Face: русский курс LLM','https://huggingface.co/learn/llm-course/ru/chapter1/1')]
LLM=[('SmolLM2-135M-Instruct, карточка и лицензия','https://huggingface.co/HuggingFaceTB/SmolLM2-135M-Instruct'),('Transformers: chat templates','https://huggingface.co/docs/transformers/chat_templating'),('Transformers: генерация','https://huggingface.co/docs/transformers/main_classes/text_generation')]
RAG=[('RAG, исходная статья','https://arxiv.org/abs/2005.11401'),('Scikit-learn: текстовые признаки','https://scikit-learn.org/stable/modules/feature_extraction.html#text-feature-extraction'),('Sentence Transformers: semantic search','https://sbert.net/examples/sentence_transformer/applications/semantic-search/README.html')]
EVAL=[('Scikit-learn: метрики','https://scikit-learn.org/stable/modules/model_evaluation.html'),('Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena','https://arxiv.org/abs/2306.05685')]

if __name__=='__main__':
    for filename in ['ml_systems_content.py','torch_content.py','nlp_content.py','llm_content.py','rag_complete.py','eval_content.py']:
        exec(compile((Path(__file__).parent/filename).read_text(encoding='utf-8'),filename,'exec'))
    out=ROOT/'metadata/production-ml-llm.json'
    out.write_text(json.dumps({'created_on':'2026-11-03','scope':'M06-M11','lessons':[{'id':x['id'],'path':f"course/lessons/{x['id']}.md",'words':x['words']} for x in LESSONS],'figures':[f"course/assets/{x['id']}.svg" for x in LESSONS],'labs':[f'labs/M{i:02d}/demo.py' for i in range(6,12)],'sources':sorted({url for x in LESSONS for _,url in x['sources']}),'actual_verification':[],'learner_status':'not_assessed'},ensure_ascii=False,indent=2),encoding='utf-8')
    print([(x['id'],x['words']) for x in LESSONS])
